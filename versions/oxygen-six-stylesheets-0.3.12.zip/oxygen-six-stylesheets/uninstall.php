<?php
/**
 * Oxygen Six Stylesheets - Uninstall
 *
 * Removes all plugin data when the plugin is deleted via WordPress admin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// The exact names, not a prefix: another plugin or theme can own a similar cap.
// A copy of PostType::get_caps(): a require can declare the class twice.
$caps = [
    'edit_o6_stylesheet',
    'read_o6_stylesheet',
    'delete_o6_stylesheet',
    'edit_o6_stylesheets',
    'edit_others_o6_stylesheets',
    'publish_o6_stylesheets',
    'read_private_o6_stylesheets',
    'delete_o6_stylesheets',
    'delete_private_o6_stylesheets',
    'delete_published_o6_stylesheets',
    'delete_others_o6_stylesheets',
    'edit_private_o6_stylesheets',
    'edit_published_o6_stylesheets',
];
foreach ( wp_roles()->role_objects as $role ) {
    foreach ( array_intersect( array_keys( $role->capabilities ), $caps ) as $cap ) {
        $role->remove_cap( $cap );
    }
}
$users = get_users( [
    'meta_key'     => $wpdb->get_blog_prefix() . 'capabilities',
    'meta_value'   => 'o6_stylesheet',
    'meta_compare' => 'LIKE',
] );
foreach ( $users as $user ) {
    foreach ( array_intersect( array_keys( $user->caps ), $caps ) as $cap ) {
        $user->remove_cap( $cap );
    }
}

// Remove plugin options and transients
delete_option( 'o6s_caps_version' );
delete_option( 'o6s_css_version' );
delete_option( 'o6s_default_term_created' );
delete_option( 'o6s_utf8mb3_notice' );
delete_transient( 'o6s_import_result' );
wp_cache_delete( 'active_stylesheets', 'o6s' );

// The deactivated plugin does not register the taxonomy. Without it, get_terms() fails
// and wp_delete_post() keeps the term relationships.
register_taxonomy( 'o6_stylesheet_cat', 'o6_stylesheet' );

// get_posts() skips trash, auto-draft and unregistered statuses.
$stylesheets = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'o6_stylesheet'" );

foreach ( $stylesheets as $post_id ) {
    wp_delete_post( $post_id, true );
}

// Delete taxonomy terms
$terms = get_terms( [
    'taxonomy'   => 'o6_stylesheet_cat',
    'hide_empty' => false,
    'fields'     => 'ids',
] );

if ( ! is_wp_error( $terms ) ) {
    foreach ( $terms as $term_id ) {
        wp_delete_term( $term_id, 'o6_stylesheet_cat' );
    }
}
delete_option( 'o6_stylesheet_cat_children' );
