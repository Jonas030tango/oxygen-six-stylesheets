<?php
/**
 * Oxygen Six Stylesheets - Frontend CSS Injection
 *
 * Handles injecting custom stylesheets into Oxygen Builder's rendering pipeline
 * and provides a wp_head fallback for non-Oxygen contexts.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Frontend {

    /**
     * Whether the Oxygen injection path was used.
     *
     * @var bool
     */
    private static $oxygen_injected = false;

    /**
     * Sanitize CSS for safe output inside <style> tags.
     * Defense-in-depth: strips dangerous patterns even though save-time sanitization
     * should have already handled them.
     *
     * @param string $css Raw CSS string.
     * @return string Sanitized CSS safe for <style> context.
     */
    public static function sanitize_css_output( $css ) {
        // Remove any HTML tags — prevents breaking out of <style> context
        $css = preg_replace( '/<[a-z\/!]/i', '/* [blocked] */', $css );
        return $css;
    }

    /**
     * Escape a post title for safe use inside a CSS comment.
     *
     * The escaped title is emitted inside a `/* ... *​/` comment within a
     * `<style>` element. Two breakout vectors are neutralized:
     *  - `*​/` / `/​*` would prematurely close or reopen the CSS comment.
     *  - A raw `</style>` (or any `<`/`>`) would terminate the `<style>`
     *    element itself, allowing stored XSS — the title is never run through
     *    sanitize_css_output(), so angle brackets must be stripped here.
     *
     * @param string $title Raw post title.
     * @return string Title safe for CSS comment context inside <style>.
     */
    private static function escape_css_comment( $title ) {
        return str_replace(
            [ '*/', '/*', '<', '>' ],
            [ '* /', '/ *', '', '' ],
            (string) $title
        );
    }

    /**
     * Add the `O6S` comment markers to the CSS of a stylesheet.
     * Only a user with `edit_o6_stylesheets` sees the title in the markers.
     *
     * @param \WP_Post $sheet
     * @param string   $css Sanitized CSS.
     * @return string
     */
    private static function wrap_css( $sheet, $css ) {
        if ( ! current_user_can( 'edit_o6_stylesheets' ) ) {
            // Oxygen 6 deletes duplicate inlineStyles entries. The post ID keeps each entry unique.
            return "/* O6S: {$sheet->ID} */\n{$css}";
        }
        $name = self::escape_css_comment( $sheet->post_title );
        return "/* O6S: {$name} */\n{$css}\n/* /O6S: {$name} */";
    }

    /**
     * Initialize frontend hooks.
     *
     * The injection path depends on which Oxygen version is active:
     * - Oxygen 6      : ScriptAndStyleHolder on init, wp_head as a safety net.
     * - Oxygen 4.x    : a single late wp_head <style> — it covers both the
     *                   frontend and the builder iframe (oxygen-iframe-template.php
     *                   calls wp_head()). Priority 1000000 lands after Oxygen's
     *                   cached universal.css (wp_head @ 999999) so user CSS wins.
     * - No Oxygen     : wp_head fallback as a standalone stylesheet manager.
     */
    public static function init() {
        if ( o6s_is_oxygen_active() ) {
            // Oxygen 6: priority 11 runs after Oxygen's init at priority 10.
            add_action( 'init', [ __CLASS__, 'inject_oxygen_styles' ], 11 );
            // Safety net if the ScriptAndStyleHolder path is unavailable.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        } elseif ( o6s_is_oxygen_classic_active() ) {
            // Oxygen 4.x (classic).
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 1000000 );
        } else {
            // Standalone: no Oxygen present.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        }
    }

    /**
     * Primary injection path: Append CSS to Oxygen's ScriptAndStyleHolder.
     * Works for both frontend rendering and builder iframe preview.
     */
    public static function inject_oxygen_styles() {
        // Only proceed if Oxygen's ScriptAndStyleHolder is available
        if ( ! class_exists( '\Breakdance\Render\ScriptAndStyleHolder' ) ) {
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        $inline_styles = [];
        foreach ( $stylesheets as $sheet ) {
            $css = get_post_meta( $sheet->ID, '_o6s_css', true );
            if ( ! empty( trim( $css ) ) ) {
                $inline_styles[] = self::wrap_css( $sheet, self::sanitize_css_output( $css ) );
            }
        }

        if ( ! empty( $inline_styles ) ) {
            \Breakdance\Render\ScriptAndStyleHolder::getInstance()->append( [
                'inlineStyles' => $inline_styles,
            ] );
            self::$oxygen_injected = true;
        }
    }

    /**
     * Fallback injection via wp_head.
     *
     * Used for the Oxygen 4.x frontend + builder iframe and for non-Oxygen
     * (standalone) contexts. On Oxygen 6 it only fires if the primary
     * ScriptAndStyleHolder path was not used.
     */
    public static function inject_fallback_styles() {
        if ( self::$oxygen_injected ) {
            return;
        }

        // Oxygen 4.x: skip the builder UI shell so user CSS does not bleed into
        // the builder chrome. The shell defines SHOW_CT_BUILDER but not
        // OXYGEN_IFRAME; the iframe preview defines both; the frontend neither.
        if ( defined( 'SHOW_CT_BUILDER' ) && ! defined( 'OXYGEN_IFRAME' ) ) {
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        foreach ( $stylesheets as $sheet ) {
            $css = get_post_meta( $sheet->ID, '_o6s_css', true );
            if ( ! empty( trim( $css ) ) ) {
                // The id uses the post ID: a title slug shows the title to visitors.
                echo "<style id=\"o6s-" . (int) $sheet->ID . "\">\n";
                echo self::wrap_css( $sheet, self::sanitize_css_output( $css ) ) . "\n";
                echo "</style>\n";
            }
        }
    }

    /**
     * Query all active stylesheets ordered by priority.
     *
     * @return \WP_Post[]
     */
    public static function get_active_stylesheets() {
        static $cache = null;
        if ( $cache !== null ) {
            return $cache;
        }

        $cache = get_posts( [
            'post_type'        => 'o6_stylesheet',
            'posts_per_page'   => -1,
            'post_status'      => 'publish',
            'orderby'          => 'o6s_priority',
            'order'            => 'ASC',
            // get_posts() suppresses filters by default. PostType::order_by_priority() is a posts_clauses filter.
            'suppress_filters' => false,
        ] );

        return $cache;
    }
}
