<?php
/**
 * Oxygen Six Stylesheets - Admin UI
 *
 * Handles meta boxes, CodeMirror editor, admin columns, and asset enqueuing.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {

    /**
     * Initialize admin hooks.
     */
    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_boxes' ] );
        add_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10, 2 );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_filter( 'manage_o6_stylesheet_posts_columns', [ __CLASS__, 'admin_columns' ] );
        add_action( 'manage_o6_stylesheet_posts_custom_column', [ __CLASS__, 'admin_column_content' ], 10, 2 );
        add_filter( 'manage_edit-o6_stylesheet_sortable_columns', [ __CLASS__, 'sortable_columns' ] );
        add_action( 'admin_notices', [ __CLASS__, 'external_url_warning' ] );
        add_action( 'wp_restore_post_revision', [ __CLASS__, 'restore_revision' ], 10, 2 );
        add_action( 'quick_edit_custom_box', [ __CLASS__, 'quick_edit_fields' ], 10, 2 );
        add_action( 'admin_footer-edit.php', [ __CLASS__, 'quick_edit_js' ] );
        add_filter( 'bulk_actions-edit-o6_stylesheet', [ __CLASS__, 'register_bulk_actions' ] );
        add_filter( 'handle_bulk_actions-edit-o6_stylesheet', [ __CLASS__, 'handle_bulk_actions' ], 10, 3 );
        add_action( 'admin_notices', [ __CLASS__, 'bulk_action_notices' ] );
        add_filter( 'removable_query_args', [ __CLASS__, 'removable_query_args' ] );
        add_action( 'admin_menu', [ __CLASS__, 'add_import_export_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_import_export' ] );
        add_action( 'admin_notices', [ __CLASS__, 'css_validation_warning' ] );
    }

    /**
     * Register meta boxes.
     */
    public static function add_meta_boxes() {
        add_meta_box(
            'o6s_css_editor',
            __( 'CSS Code', 'oxygen-six-stylesheets' ),
            [ __CLASS__, 'render_css_editor' ],
            'o6_stylesheet',
            'normal',
            'high'
        );

        add_meta_box(
            'o6s_settings',
            __( 'Stylesheet Settings', 'oxygen-six-stylesheets' ),
            [ __CLASS__, 'render_settings' ],
            'o6_stylesheet',
            'side',
            'high'
        );
    }

    /**
     * Render the CSS code editor meta box.
     *
     * @param \WP_Post $post
     */
    public static function render_css_editor( $post ) {
        wp_nonce_field( 'o6s_save_stylesheet', 'o6s_nonce' );
        $css = get_post_meta( $post->ID, '_o6s_css', true );
        ?>
        <div class="o6s-css-editor-wrap">
            <textarea id="o6s-css-code" name="o6s_css" rows="20"><?php echo esc_textarea( $css ); ?></textarea>
        </div>
        <?php
    }

    /**
     * Render the settings meta box (active toggle + priority).
     *
     * @param \WP_Post $post
     */
    public static function render_settings( $post ) {
        $priority = get_post_meta( $post->ID, '_o6s_priority', true );

        // Default for new posts
        if ( $priority === '' ) {
            $priority = '10';
        }
        ?>
        <div class="o6s-meta-field o6s-priority-field">
            <label for="o6s-priority">
                <?php esc_html_e( 'Priority', 'oxygen-six-stylesheets' ); ?>
            </label>
            <input type="number" id="o6s-priority" name="o6s_priority" value="<?php echo esc_attr( $priority ); ?>" min="0" max="999" step="1" style="width: 80px;">
            <p class="description">
                <?php esc_html_e( 'Lower number = loads earlier. Default: 10.', 'oxygen-six-stylesheets' ); ?>
            </p>
        </div>

        <?php if ( $post->post_modified && $post->post_modified !== '0000-00-00 00:00:00' ) : ?>
        <div class="o6s-meta-field o6s-audit-info">
            <strong><?php esc_html_e( 'Last modified', 'oxygen-six-stylesheets' ); ?></strong>
            <p class="description">
                <?php
                $last_editor_id = get_post_meta( $post->ID, '_edit_last', true );
                $author = $last_editor_id ? get_userdata( $last_editor_id ) : get_userdata( $post->post_author );
                printf(
                    /* translators: %1$s: date, %2$s: username */
                    esc_html__( '%1$s by %2$s', 'oxygen-six-stylesheets' ),
                    esc_html( get_the_modified_date( '', $post ) . ' ' . get_the_modified_time( '', $post ) ),
                    $author ? esc_html( $author->display_name ) : esc_html__( 'Unknown', 'oxygen-six-stylesheets' )
                );
                ?>
            </p>
        </div>
        <?php endif; ?>
        <?php
    }

    /**
     * Save meta box data.
     *
     * @param int      $post_id
     * @param \WP_Post $post
     */
    public static function save_post( $post_id, $post ) {
        // Verify nonce — accept either full-edit or quick-edit nonce
        $full_edit_valid  = isset( $_POST['o6s_nonce'] )
            && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_nonce'] ) ), 'o6s_save_stylesheet' );
        $quick_edit_valid = isset( $_POST['o6s_quick_nonce'] )
            && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_quick_nonce'] ) ), 'o6s_quick_edit' );
        if ( ! $full_edit_valid && ! $quick_edit_valid ) {
            return;
        }

        // Check autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save CSS (full editor only). The quick-edit form carries the
        // priority field only, so the CSS body is gated on the full-edit
        // nonce — the quick-edit path must never write CSS. is_string()
        // guards against a crafted o6s_css[] array being stored as meta and
        // later fataling a frontend trim() call.
        if ( $full_edit_valid && isset( $_POST['o6s_css'] ) && is_string( $_POST['o6s_css'] ) ) {
            $css = wp_unslash( $_POST['o6s_css'] );
            $css = self::sanitize_css_on_save( $css );
            // The WordPress write functions unslash their input. wp_slash() keeps CSS escapes such as \201C.
            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );

            // Also store in post_content so WordPress revisions track CSS changes.
            // We unhook save_post first to prevent infinite loop.
            remove_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10 );
            wp_update_post( wp_slash( [
                'ID'           => $post_id,
                'post_content' => $css,
            ] ) );
            add_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10, 2 );
        }

        // Save priority
        if ( isset( $_POST['o6s_priority'] ) ) {
            $priority = absint( wp_unslash( $_POST['o6s_priority'] ) );
            update_post_meta( $post_id, '_o6s_priority', $priority );
        }
    }

    /**
     * Sanitize CSS content on save.
     * Strips dangerous patterns that could be used for XSS or legacy browser exploits.
     *
     * @param string $css Raw CSS input.
     * @return string Sanitized CSS.
     */
    public static function sanitize_css_on_save( $css ) {
        // Strip any HTML tags to prevent XSS breakout when rendered inside <style> tags
        $css = preg_replace( '/<[a-z\/!]/i', '/* [removed] */', $css );

        // Strip @import rules — can load external stylesheets for data exfiltration
        $css = preg_replace( '/@import\b/i', '/* [removed:import] */', $css );

        // Strip expression() — legacy IE CSS expression attack vector
        // Use pattern that catches CSS escape sequence obfuscation (e.g. \65xpression)
        $css = preg_replace( '/e\s*x\s*p\s*r\s*e\s*s\s*s\s*i\s*o\s*n\s*\(/i', '/* [removed] (', $css );

        // Strip -moz-binding — legacy Firefox XBL attack vector
        $css = preg_replace( '/-\s*m\s*o\s*z\s*-\s*b\s*i\s*n\s*d\s*i\s*n\s*g\s*:/i', '/* [removed] :', $css );

        // Strip behavior: — legacy IE HTC attack vector
        $css = preg_replace( '/b\s*e\s*h\s*a\s*v\s*i\s*o\s*r\s*:/i', '/* [removed] :', $css );

        // Strip javascript: in url() values
        $css = preg_replace( '/j\s*a\s*v\s*a\s*s\s*c\s*r\s*i\s*p\s*t\s*:/i', '/* [removed] :', $css );

        return $css;
    }

    /**
     * When a revision is restored, sync post_content back to _o6s_css meta.
     *
     * @param int $post_id     The post ID being restored to.
     * @param int $revision_id The revision ID being restored.
     */
    public static function restore_revision( $post_id, $revision_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $revision = get_post( $revision_id );
        if ( $revision ) {
            $css = self::sanitize_css_on_save( $revision->post_content );
            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );
        }
    }

    /**
     * Show admin notice if the current stylesheet contains external url() references.
     */
    public static function external_url_warning() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' || $screen->base !== 'post' ) {
            return;
        }

        global $post;
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $css = get_post_meta( $post->ID, '_o6s_css', true );
        if ( empty( $css ) ) {
            return;
        }

        // Check for url() with external http(s) references
        if ( preg_match( '/url\s*\(\s*[\'"]?\s*https?:\/\//i', $css ) ) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <strong><?php esc_html_e( 'Security Notice', 'oxygen-six-stylesheets' ); ?>:</strong>
                    <?php esc_html_e( 'This stylesheet contains external url() references. External URLs can load resources from third-party servers and may be used for data exfiltration via CSS attribute selectors. Only use trusted domains.', 'oxygen-six-stylesheets' ); ?>
                </p>
            </div>
            <?php
        }
    }

    /**
     * Enqueue CodeMirror and admin CSS on stylesheet edit screens.
     *
     * @param string $hook
     */
    public static function enqueue_assets( $hook ) {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' ) {
            return;
        }

        // Admin list and edit styles
        wp_enqueue_style(
            'o6s-admin',
            O6S_PLUGIN_URL . 'assets/css/admin.css',
            [],
            O6S_VERSION
        );

        // On edit screens: CodeMirror + hide visibility options
        if ( $hook === 'post.php' || $hook === 'post-new.php' ) {
            // Hide visibility option -- stylesheets are always public
            wp_add_inline_style( 'o6s-admin', '#visibility-action { display: none; }' );

            $cm_settings = wp_enqueue_code_editor( [ 'type' => 'text/css' ] );

            if ( $cm_settings !== false ) {
                wp_add_inline_script(
                    'code-editor',
                    sprintf(
                        'jQuery(function($) {
                            if ($("#o6s-css-code").length) {
                                var editor = wp.codeEditor.initialize($("#o6s-css-code"), %s);
                                // Auto-resize
                                editor.codemirror.on("change", function(cm) {
                                    cm.refresh();
                                });
                            }
                        });',
                        wp_json_encode( $cm_settings )
                    )
                );
            }
        }
    }

    /**
     * Add custom admin columns.
     *
     * @param array $columns
     * @return array
     */
    public static function admin_columns( $columns ) {
        $new_columns = [];
        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;
            if ( $key === 'title' ) {
                $new_columns['o6s_active']   = __( 'Active', 'oxygen-six-stylesheets' );
                $new_columns['o6s_priority'] = __( 'Priority', 'oxygen-six-stylesheets' );
                $new_columns['o6s_size']     = __( 'CSS Size', 'oxygen-six-stylesheets' );
            }
        }
        return $new_columns;
    }

    /**
     * Render custom admin column content.
     *
     * @param string $column
     * @param int    $post_id
     */
    public static function admin_column_content( $column, $post_id ) {
        switch ( $column ) {
            case 'o6s_active':
                $is_active = ( get_post_status( $post_id ) === 'publish' );
                echo $is_active
                    ? '<span class="o6s-status-dot o6s-status-dot--active" title="' . esc_attr__( 'Active', 'oxygen-six-stylesheets' ) . '"></span> ' . esc_html__( 'Active', 'oxygen-six-stylesheets' )
                    : '<span class="o6s-status-dot o6s-status-dot--inactive" title="' . esc_attr__( 'Inactive', 'oxygen-six-stylesheets' ) . '"></span> ' . esc_html__( 'Inactive', 'oxygen-six-stylesheets' );
                break;

            case 'o6s_priority':
                $priority = get_post_meta( $post_id, '_o6s_priority', true );
                echo esc_html( $priority !== '' ? $priority : '10' );
                break;

            case 'o6s_size':
                $css = get_post_meta( $post_id, '_o6s_css', true );
                if ( ! empty( $css ) ) {
                    $bytes = strlen( $css );
                    if ( $bytes >= 1024 ) {
                        echo esc_html( round( $bytes / 1024, 1 ) . ' KB' );
                    } else {
                        echo esc_html( $bytes . ' B' );
                    }
                } else {
                    echo '<span class="description">' . esc_html__( 'Empty', 'oxygen-six-stylesheets' ) . '</span>';
                }
                break;
        }
    }

    /**
     * Make columns sortable.
     *
     * @param array $columns
     * @return array
     */
    public static function sortable_columns( $columns ) {
        $columns['o6s_priority'] = 'o6s_priority';
        return $columns;
    }

    /**
     * Add active toggle and priority field to quick-edit.
     *
     * @param string $column_name
     * @param string $post_type
     */
    public static function quick_edit_fields( $column_name, $post_type ) {
        if ( $post_type !== 'o6_stylesheet' || $column_name !== 'o6s_active' ) {
            return;
        }
        wp_nonce_field( 'o6s_quick_edit', 'o6s_quick_nonce' );
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label class="inline-edit-group">
                    <span class="title"><?php esc_html_e( 'Priority', 'oxygen-six-stylesheets' ); ?></span>
                    <input type="number" name="o6s_priority" min="0" max="999" step="1" style="width: 60px;">
                </label>
            </div>
        </fieldset>
        <?php
    }

    /**
     * JavaScript to populate quick-edit fields with current values.
     */
    public static function quick_edit_js() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' ) {
            return;
        }
        ?>
        <script>
        jQuery(function($) {
            var origInlineEdit = inlineEditPost.edit;
            inlineEditPost.edit = function(id) {
                origInlineEdit.apply(this, arguments);
                var postId = 0;
                if (typeof id === 'object') {
                    postId = parseInt(this.getId(id));
                }
                if (postId > 0) {
                    var row = $('#post-' + postId);
                    var priority = row.find('.column-o6s_priority').text().trim();
                    var editRow = $('#edit-' + postId);
                    editRow.find('input[name="o6s_priority"]').val(priority);
                }
            };
        });
        </script>
        <?php
    }

    /**
     * Register custom bulk actions.
     *
     * @param array $actions
     * @return array
     */
    public static function register_bulk_actions( $actions ) {
        if ( current_user_can( 'publish_o6_stylesheets' ) ) {
            $actions['o6s_activate'] = __( 'Activate', 'oxygen-six-stylesheets' );
        }
        $actions['o6s_deactivate'] = __( 'Deactivate', 'oxygen-six-stylesheets' );
        return $actions;
    }

    /**
     * Handle custom bulk actions.
     *
     * @param string $redirect_url
     * @param string $action
     * @param array  $post_ids
     * @return string
     */
    public static function handle_bulk_actions( $redirect_url, $action, $post_ids ) {
        if ( $action !== 'o6s_activate' && $action !== 'o6s_deactivate' ) {
            return $redirect_url;
        }

        $new_status = ( $action === 'o6s_activate' ) ? 'publish' : 'draft';
        $count = 0;

        // wp_update_post() checks no capability.
        if ( $action === 'o6s_activate' && ! current_user_can( 'publish_o6_stylesheets' ) ) {
            return $redirect_url;
        }

        foreach ( $post_ids as $post_id ) {
            // Skip unchanged posts: an update of a draft resets its date.
            // Skip trashed posts: only an untrash restores them correctly.
            if ( get_post_type( $post_id ) !== 'o6_stylesheet'
                || in_array( get_post_status( $post_id ), [ $new_status, 'trash' ], true )
                || ! current_user_can( 'edit_post', $post_id ) ) {
                continue;
            }
            wp_update_post( [ 'ID' => $post_id, 'post_status' => $new_status ] );
            // A post with a future date becomes `future` and does not count.
            if ( get_post_status( $post_id ) === $new_status ) {
                $count++;
            }
        }

        return add_query_arg( [
            'o6s_bulk_action' => $action,
            'o6s_bulk_count'  => $count,
        ], $redirect_url );
    }

    /**
     * Add the notice args to the core list, so a reload does not show the notice again.
     *
     * @param array $args
     * @return array
     */
    public static function removable_query_args( $args ) {
        $args[] = 'o6s_bulk_action';
        $args[] = 'o6s_bulk_count';
        return $args;
    }

    /**
     * Show admin notice after bulk action.
     */
    public static function bulk_action_notices() {
        if ( ! isset( $_GET['o6s_bulk_action'] ) || ! isset( $_GET['o6s_bulk_count'] ) ) {
            return;
        }

        $action = sanitize_text_field( wp_unslash( $_GET['o6s_bulk_action'] ) );
        $count  = absint( wp_unslash( $_GET['o6s_bulk_count'] ) );

        if ( $action === 'o6s_activate' ) {
            $message = sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d stylesheet activated.', '%d stylesheets activated.', $count, 'oxygen-six-stylesheets' ),
                $count
            );
        } elseif ( $action === 'o6s_deactivate' ) {
            $message = sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d stylesheet deactivated.', '%d stylesheets deactivated.', $count, 'oxygen-six-stylesheets' ),
                $count
            );
        } else {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
    }

    /**
     * Validate CSS and return an array of warning messages.
     *
     * @param string $css The CSS to validate.
     * @return string[] Array of warning messages (empty if valid).
     */
    public static function validate_css( $css ) {
        $warnings = [];

        if ( empty( trim( $css ) ) ) {
            return $warnings;
        }

        // Strip comments and strings to avoid false positives
        $stripped = preg_replace( '/\/\*.*?\*\//s', '', $css );
        $stripped = preg_replace( '/"[^"]*"|\'[^\']*\'/', '""', $stripped );

        // Check for unbalanced braces
        $open  = substr_count( $stripped, '{' );
        $close = substr_count( $stripped, '}' );
        if ( $open !== $close ) {
            $warnings[] = sprintf(
                /* translators: %1$d: opening braces, %2$d: closing braces */
                __( 'Unbalanced braces: %1$d opening { vs %2$d closing }.', 'oxygen-six-stylesheets' ),
                $open,
                $close
            );
        }

        // Check for unbalanced parentheses
        $open_parens  = substr_count( $stripped, '(' );
        $close_parens = substr_count( $stripped, ')' );
        if ( $open_parens !== $close_parens ) {
            $warnings[] = sprintf(
                /* translators: %1$d: opening parens, %2$d: closing parens */
                __( 'Unbalanced parentheses: %1$d opening ( vs %2$d closing ).', 'oxygen-six-stylesheets' ),
                $open_parens,
                $close_parens
            );
        }

        // Check for empty rule blocks
        if ( preg_match( '/\{[\s]*\}/', $stripped ) ) {
            $warnings[] = __( 'Empty rule block detected (a selector with no properties).', 'oxygen-six-stylesheets' );
        }

        return $warnings;
    }

    /**
     * Show CSS validation warnings on the edit screen.
     */
    public static function css_validation_warning() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' || $screen->base !== 'post' ) {
            return;
        }

        global $post;
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $css = get_post_meta( $post->ID, '_o6s_css', true );
        if ( empty( $css ) ) {
            return;
        }

        $warnings = self::validate_css( $css );
        if ( empty( $warnings ) ) {
            return;
        }

        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>' . esc_html__( 'CSS Validation', 'oxygen-six-stylesheets' ) . ':</strong></p>';
        echo '<ul style="list-style: disc; padding-left: 20px;">';
        foreach ( $warnings as $warning ) {
            echo '<li>' . esc_html( $warning ) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }

    /**
     * Register the Import/Export submenu page.
     */
    public static function add_import_export_page() {
        add_submenu_page(
            'edit.php?post_type=o6_stylesheet',
            __( 'Import / Export', 'oxygen-six-stylesheets' ),
            __( 'Import / Export', 'oxygen-six-stylesheets' ),
            'manage_options',
            'o6s-import-export',
            [ __CLASS__, 'render_import_export_page' ]
        );
    }

    /**
     * Render the Import/Export page.
     */
    public static function render_import_export_page() {
        $import_result = get_transient( 'o6s_import_result' );
        if ( $import_result ) {
            delete_transient( 'o6s_import_result' );
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Import / Export Stylesheets', 'oxygen-six-stylesheets' ); ?></h1>

            <?php if ( $import_result ) : ?>
                <div class="notice notice-<?php echo esc_attr( $import_result['success'] ? 'success' : 'error' ); ?> is-dismissible">
                    <p><?php echo esc_html( $import_result['message'] ); ?></p>
                </div>
            <?php endif; ?>

            <div class="card" style="max-width: 600px; margin-bottom: 20px;">
                <h2><?php esc_html_e( 'Export', 'oxygen-six-stylesheets' ); ?></h2>
                <p><?php esc_html_e( 'Download all stylesheets as a JSON file. Includes CSS, active status, priority, and categories.', 'oxygen-six-stylesheets' ); ?></p>
                <form method="post">
                    <?php wp_nonce_field( 'o6s_export', 'o6s_export_nonce' ); ?>
                    <input type="hidden" name="o6s_action" value="export">
                    <?php submit_button( __( 'Export Stylesheets', 'oxygen-six-stylesheets' ), 'primary', 'submit', false ); ?>
                </form>
            </div>

            <div class="card" style="max-width: 600px;">
                <h2><?php esc_html_e( 'Import', 'oxygen-six-stylesheets' ); ?></h2>
                <p><?php esc_html_e( 'Upload a previously exported JSON file. Existing stylesheets with the same name will be skipped.', 'oxygen-six-stylesheets' ); ?></p>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'o6s_import', 'o6s_import_nonce' ); ?>
                    <input type="hidden" name="o6s_action" value="import">
                    <p>
                        <input type="file" name="o6s_import_file" accept=".json">
                    </p>
                    <?php submit_button( __( 'Import Stylesheets', 'oxygen-six-stylesheets' ), 'secondary', 'submit', false ); ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Handle import/export form submissions.
     */
    public static function handle_import_export() {
        if ( ! isset( $_POST['o6s_action'] ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $action = sanitize_text_field( wp_unslash( $_POST['o6s_action'] ) );

        if ( $action === 'export' ) {
            self::do_export();
        } elseif ( $action === 'import' ) {
            self::do_import();
        }
    }

    /**
     * Export all stylesheets as JSON.
     */
    private static function do_export() {
        if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_export_nonce'] ?? '' ) ), 'o6s_export' ) ) {
            return;
        }

        $stylesheets = get_posts( [
            'post_type'      => 'o6_stylesheet',
            'posts_per_page' => -1,
            'post_status'    => 'any',
        ] );

        $export_data = [
            'plugin'  => 'oxygen-six-stylesheets',
            'version' => O6S_VERSION,
            'date'    => current_time( 'mysql' ),
            'items'   => [],
        ];

        foreach ( $stylesheets as $sheet ) {
            $categories = wp_get_object_terms( $sheet->ID, 'o6_stylesheet_cat', [ 'fields' => 'names' ] );
            $priority   = get_post_meta( $sheet->ID, '_o6s_priority', true );

            $export_data['items'][] = [
                'title'      => $sheet->post_title,
                'css'        => get_post_meta( $sheet->ID, '_o6s_css', true ),
                'active'     => ( $sheet->post_status === 'publish' ) ? '1' : '0',
                'priority'   => $priority !== '' ? $priority : '10',
                'categories' => is_wp_error( $categories ) ? [] : $categories,
                'status'     => $sheet->post_status,
            ];
        }

        $filename = 'o6s-stylesheets-' . gmdate( 'Y-m-d' ) . '.json';
        header( 'Content-Type: application/json' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        echo wp_json_encode( $export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
        exit;
    }

    /**
     * Import stylesheets from JSON file.
     */
    private static function do_import() {
        if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_import_nonce'] ?? '' ) ), 'o6s_import' ) ) {
            return;
        }

        // wp_insert_post() checks no capability.
        if ( ! current_user_can( 'edit_o6_stylesheets' ) ) {
            return;
        }

        if ( empty( $_FILES['o6s_import_file']['tmp_name'] ) ) {
            set_transient( 'o6s_import_result', [
                'success' => false,
                'message' => __( 'No file selected.', 'oxygen-six-stylesheets' ),
            ], 30 );
            return;
        }

        // Limit import file size to 2 MB to prevent memory exhaustion
        $max_size = 2 * 1024 * 1024;
        if ( $_FILES['o6s_import_file']['size'] > $max_size ) {
            set_transient( 'o6s_import_result', [
                'success' => false,
                'message' => __( 'Import file too large (max 2 MB).', 'oxygen-six-stylesheets' ),
            ], 30 );
            return;
        }

        $tmp_file = $_FILES['o6s_import_file']['tmp_name'];
        if ( ! is_uploaded_file( $tmp_file ) ) {
            set_transient( 'o6s_import_result', [
                'success' => false,
                'message' => __( 'Invalid file upload.', 'oxygen-six-stylesheets' ),
            ], 30 );
            return;
        }

        $file_content = file_get_contents( $tmp_file );
        $data = json_decode( $file_content, true );

        if ( ! $data || ! isset( $data['items'] ) || ! is_array( $data['items'] ) ) {
            set_transient( 'o6s_import_result', [
                'success' => false,
                'message' => __( 'Invalid JSON file.', 'oxygen-six-stylesheets' ),
            ], 30 );
            return;
        }

        $imported = 0;
        $skipped  = 0;

        foreach ( $data['items'] as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['title'] ) || ! is_string( $item['title'] ) ) {
                $skipped++;
                continue;
            }

            // The editor stores the title with trim() only. The duplicate lookup must see the same value.
            $title = trim( $item['title'] );
            if ( '' === $title ) {
                $skipped++;
                continue;
            }

            // Check for existing stylesheet with same title
            $existing = get_posts( [
                'post_type'      => 'o6_stylesheet',
                'title'          => wp_slash( $title ),
                'posts_per_page' => 1,
                'post_status'    => 'any',
                'fields'         => 'ids',
            ] );

            if ( ! empty( $existing ) ) {
                $skipped++;
                continue;
            }

            $css = isset( $item['css'] ) && is_string( $item['css'] ) ? $item['css'] : '';
            $css = self::sanitize_css_on_save( $css );

            // Determine post status: honor 'active' field for backward compat,
            // fall back to 'status' field, default to publish.
            if ( isset( $item['active'] ) && $item['active'] === '0' ) {
                $status = 'draft';
            } else {
                $allowed_statuses = [ 'publish', 'draft', 'pending' ];
                $status = isset( $item['status'] ) && in_array( $item['status'], $allowed_statuses, true )
                    ? $item['status']
                    : 'publish';
            }
            if ( $status === 'publish' && ! current_user_can( 'publish_o6_stylesheets' ) ) {
                $status = 'draft';
            }

            $post_id = wp_insert_post( wp_slash( [
                'post_type'    => 'o6_stylesheet',
                'post_title'   => $title,
                'post_content' => $css,
                'post_status'  => $status,
            ] ) );

            if ( is_wp_error( $post_id ) ) {
                $skipped++;
                continue;
            }

            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );
            update_post_meta( $post_id, '_o6s_priority', isset( $item['priority'] ) ? absint( $item['priority'] ) : 10 );

            // Assign categories
            if ( ! empty( $item['categories'] ) && is_array( $item['categories'] ) ) {
                $term_ids = [];
                foreach ( $item['categories'] as $cat_name ) {
                    if ( ! is_string( $cat_name ) || empty( trim( $cat_name ) ) ) {
                        continue;
                    }
                    $term = get_term_by( 'name', wp_slash( $cat_name ), 'o6_stylesheet_cat' );
                    if ( ! $term ) {
                        $result = wp_insert_term( wp_slash( sanitize_text_field( $cat_name ) ), 'o6_stylesheet_cat' );
                        if ( ! is_wp_error( $result ) ) {
                            $term_ids[] = $result['term_id'];
                        }
                    } else {
                        $term_ids[] = $term->term_id;
                    }
                }
                if ( ! empty( $term_ids ) ) {
                    wp_set_object_terms( $post_id, $term_ids, 'o6_stylesheet_cat' );
                }
            }

            $imported++;
        }

        set_transient( 'o6s_import_result', [
            'success' => true,
            'message' => sprintf(
                /* translators: %1$d: imported count, %2$d: skipped count */
                __( '%1$d stylesheets imported, %2$d skipped (duplicate or invalid).', 'oxygen-six-stylesheets' ),
                $imported,
                $skipped
            ),
        ], 30 );
    }
}
