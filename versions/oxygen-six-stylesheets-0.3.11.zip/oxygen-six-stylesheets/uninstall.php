<?php
/**
 * Oxygen Six Stylesheets - Uninstall
 *
 * Removes all plugin data when the plugin is deleted via WordPress admin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Remove custom capabilities from administrator role
$role = get_role( 'administrator' );
if ( $role ) {
    $caps = [
        'edit_o6_stylesheet',
        'read_o6_stylesheet',
        'delete_o6_stylesheet',
        'edit_o6_stylesheets',
        'edit_others_o6_stylesheets',
        'publish_o6_stylesheets',
        'read_private_o6_stylesheets',
        'delete_o6_stylesheets',
        'delete_private_o6_stylesheets',
        'delete_published_o6_stylesheets',
        'delete_others_o6_stylesheets',
        'edit_private_o6_stylesheets',
        'edit_published_o6_stylesheets',
    ];
    foreach ( $caps as $cap ) {
        $role->remove_cap( $cap );
    }
}

// Remove plugin options and transients
delete_option( 'o6s_caps_version' );
delete_option( 'o6s_css_version' );
delete_option( 'o6s_default_term_created' );
delete_option( 'o6s_utf8mb3_notice' );
delete_transient( 'o6s_import_result' );

// Delete all stylesheets (CPT posts and their meta)
$stylesheets = get_posts( [
    'post_type'      => 'o6_stylesheet',
    'posts_per_page' => -1,
    'post_status'    => 'any',
    'fields'         => 'ids',
] );

foreach ( $stylesheets as $post_id ) {
    wp_delete_post( $post_id, true );
}

// Delete taxonomy terms
$terms = get_terms( [
    'taxonomy'   => 'o6_stylesheet_cat',
    'hide_empty' => false,
    'fields'     => 'ids',
] );

if ( ! is_wp_error( $terms ) ) {
    foreach ( $terms as $term_id ) {
        wp_delete_term( $term_id, 'o6_stylesheet_cat' );
    }
}
