<?php
/**
 * Plugin Name: Oxygen Six Stylesheets
 * Plugin URI: https://github.com/Jonas030tango/oxygen-six-stylesheets
 * Description: Add custom, named stylesheets to Oxygen Builder (4.x classic and 6) — editable from the WordPress backend, organized with categories, and loaded live in the builder.
 * Version: 0.3.14
 * Author: Jonas Karanlik Zadow
 * Author URI: https://github.com/Jonas030tango
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: oxygen-six-stylesheets
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'O6S_VERSION', '0.3.14' );
define( 'O6S_PLUGIN_FILE', __FILE__ );
define( 'O6S_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'O6S_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check if Oxygen Builder 6 is active.
 */
function o6s_is_oxygen_active() {
    return defined( 'BREAKDANCE_MODE' ) && BREAKDANCE_MODE === 'oxygen';
}

/**
 * Check if Oxygen Builder 4.x (classic) is active.
 *
 * The classic builder defines CT_VERSION but not BREAKDANCE_MODE. Oxygen 6 is
 * checked first so a v6 install is never misclassified as classic.
 */
function o6s_is_oxygen_classic_active() {
    return defined( 'CT_VERSION' ) && ! o6s_is_oxygen_active();
}

/**
 * Resolve which Oxygen builder is active.
 *
 * @return string 'oxygen6' | 'classic' | '' (no Oxygen).
 */
function o6s_oxygen_context() {
    if ( o6s_is_oxygen_active() ) {
        return 'oxygen6';
    }
    if ( o6s_is_oxygen_classic_active() ) {
        return 'classic';
    }
    return '';
}

/**
 * Show admin notice if no supported Oxygen Builder version is active.
 */
function o6s_admin_notice_no_oxygen() {
    if ( o6s_oxygen_context() !== '' ) {
        return;
    }
    ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php esc_html_e( 'Oxygen Six Stylesheets', 'oxygen-six-stylesheets' ); ?>:</strong>
            <?php esc_html_e( 'Oxygen Builder is not active. The plugin will still work as a standalone stylesheet manager, but styles will not appear in the Oxygen builder.', 'oxygen-six-stylesheets' ); ?>
        </p>
    </div>
    <?php
}
add_action( 'admin_notices', 'o6s_admin_notice_no_oxygen' );

/**
 * @param callable $callback
 * @param bool     $network_wide
 */
function o6s_for_each_site( $callback, $network_wide ) {
    if ( ! is_multisite() || ! $network_wide ) {
        $callback();
        return;
    }
    foreach ( get_sites( [ 'number' => 0, 'fields' => 'ids', 'network_id' => get_current_network_id() ] ) as $site_id ) {
        switch_to_blog( $site_id );
        $callback();
        restore_current_blog();
    }
}

/**
 * A utf8mb3 column cannot store 4-byte characters such as emoji, so activation checks the tables.
 *
 * @param bool $network_wide
 */
function o6s_activate( $network_wide = false ) {
    // The writes while the plugin was inactive changed no stamp. The Files class can be missing here.
    o6s_for_each_site( function () {
        update_option( 'o6s_rev', uniqid( '', true ), ! wp_using_ext_object_cache() );
        if ( ! wp_next_scheduled( 'o6s_daily_check' ) ) {
            wp_schedule_event( time(), 'daily', 'o6s_daily_check' );
        }
    }, $network_wide );

    global $wpdb;
    foreach ( [ [ $wpdb->posts, 'post_content' ], [ $wpdb->postmeta, 'meta_value' ] ] as $col ) {
        if ( in_array( $wpdb->get_col_charset( $col[0], $col[1] ), [ 'utf8', 'utf8mb3' ], true ) ) {
            update_option( 'o6s_utf8mb3_notice', '1', true );
            return;
        }
    }
    delete_option( 'o6s_utf8mb3_notice' );
}
register_activation_hook( __FILE__, 'o6s_activate' );

/**
 * @param bool $network_wide
 */
function o6s_deactivate( $network_wide = false ) {
    $plugin = plugin_basename( O6S_PLUGIN_FILE );
    // The network list keeps the plugin active on this site.
    if ( ! $network_wide && is_multisite() && is_plugin_active_for_network( $plugin ) ) {
        return;
    }
    o6s_for_each_site( function () use ( $network_wide, $plugin ) {
        if ( ! $network_wide || ! in_array( $plugin, (array) get_option( 'active_plugins', [] ), true ) ) {
            wp_clear_scheduled_hook( 'o6s_daily_check' );
        }
    }, $network_wide );
}
register_deactivation_hook( __FILE__, 'o6s_deactivate' );

/**
 * Show the utf8mb3 warning once, to a user who can manage plugins.
 */
function o6s_admin_notice_utf8mb3() {
    // get_option() runs a query for a missing option. The autoloaded options are already in memory.
    if ( ! isset( wp_load_alloptions()['o6s_utf8mb3_notice'] ) || ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    // The block editor hides admin notices, so the one display must not happen there.
    $screen = get_current_screen();
    if ( $screen && $screen->is_block_editor() ) {
        return;
    }
    delete_option( 'o6s_utf8mb3_notice' );
    ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php esc_html_e( 'Oxygen Six Stylesheets', 'oxygen-six-stylesheets' ); ?>:</strong>
            <?php esc_html_e( 'Your database tables use the utf8mb3 character set. A stylesheet cannot contain emoji or other 4-byte characters, and the import can create duplicates of titles with emoji. Ask your host to convert the tables to utf8mb4.', 'oxygen-six-stylesheets' ); ?>
        </p>
    </div>
    <?php
}
add_action( 'admin_notices', 'o6s_admin_notice_utf8mb3' );

/**
 * Load plugin files.
 */
function o6s_init() {
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-post-type.php';
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-admin.php';
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-frontend.php';
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-files.php';

    OxygenSixStylesheets\PostType::register();
    OxygenSixStylesheets\Admin::init();
    OxygenSixStylesheets\Frontend::init();
    OxygenSixStylesheets\Files::init();
}
add_action( 'plugins_loaded', 'o6s_init' );
