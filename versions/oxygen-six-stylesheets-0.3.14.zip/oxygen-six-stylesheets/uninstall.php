<?php
/**
 * Oxygen Six Stylesheets - Uninstall
 *
 * Removes all plugin data when the plugin is deleted via WordPress admin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// The exact names, not a prefix: another plugin or theme can own a similar cap.
// A copy of PostType::get_caps(): a require can declare the class twice.
$caps = [
    'edit_o6_stylesheet',
    'read_o6_stylesheet',
    'delete_o6_stylesheet',
    'edit_o6_stylesheets',
    'edit_others_o6_stylesheets',
    'publish_o6_stylesheets',
    'read_private_o6_stylesheets',
    'delete_o6_stylesheets',
    'delete_private_o6_stylesheets',
    'delete_published_o6_stylesheets',
    'delete_others_o6_stylesheets',
    'edit_private_o6_stylesheets',
    'edit_published_o6_stylesheets',
];
foreach ( wp_roles()->role_objects as $role ) {
    foreach ( array_intersect( array_keys( $role->capabilities ), $caps ) as $cap ) {
        $role->remove_cap( $cap );
    }
}
$users = get_users( [
    'meta_key'     => $wpdb->get_blog_prefix() . 'capabilities',
    'meta_value'   => 'o6_stylesheet',
    'meta_compare' => 'LIKE',
] );
foreach ( $users as $user ) {
    foreach ( array_intersect( array_keys( $user->caps ), $caps ) as $cap ) {
        $user->remove_cap( $cap );
    }
}

// Remove plugin options and transients
delete_option( 'o6s_caps_version' );
delete_option( 'o6s_css_version' );
delete_option( 'o6s_css_unchecked' );
delete_option( 'o6s_default_term_created' );
delete_option( 'o6s_utf8mb3_notice' );
delete_transient( 'o6s_import_result' );
wp_cache_delete( 'active_stylesheets', 'o6s' );

// WordPress does not load the plugin when the uninstall runs in its own request.
if ( ! class_exists( 'OxygenSixStylesheets\\Files' ) ) {
    require_once __DIR__ . '/includes/class-o6s-files.php';
}
$o6s_delete_files = function ( $switched ) {
    // Wait for a running build. The lock row goes with the other options below.
    for ( $i = 0; $i < 65 && OxygenSixStylesheets\Files::lock() === ''; $i++ ) {
        sleep( 1 );
    }
    // A site can still list the plugin. Files::plugin_active() then stops the next build of that site.
    $active = (array) get_option( 'active_plugins', [] );
    if ( in_array( WP_UNINSTALL_PLUGIN, $active, true ) ) {
        update_option( 'active_plugins', array_values( array_diff( $active, [ WP_UNINSTALL_PLUGIN ] ) ) );
    }
    wp_clear_scheduled_hook( 'o6s_daily_check' );
    $dir      = wp_get_upload_dir()['basedir'] . '/o6s';
    $prefixes = [ OxygenSixStylesheets\Files::prefix() ];
    // After switch_to_blog(), prefix() of another site can be wrong.
    // The last manifest of the site holds the hash that its builds used.
    $manifest = get_option( 'o6s_files' );
    if ( $switched && is_array( $manifest ) && ! empty( $manifest['site'] ) ) {
        $prefixes[] = 'o6s-' . substr( $manifest['site'], 0, 8 );
    }
    foreach ( array_unique( $prefixes ) as $prefix ) {
        foreach ( glob( $dir . '/' . $prefix . '*' ) ?: [] as $file ) {
            @unlink( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
    }
    foreach ( [ 'o6s_settings', 'o6s_rev', 'o6s_files', 'o6s_files_lock' ] as $option ) {
        delete_option( $option );
    }
    delete_transient( 'o6s_rebuild_result' );
    $list = is_dir( $dir ) ? scandir( $dir ) : false;
    if ( is_array( $list ) && ! array_diff( $list, [ '.', '..', 'index.php' ] ) ) {
        @unlink( $dir . '/index.php' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        @rmdir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
    }
};
if ( is_multisite() ) {
    $o6s_current = get_current_blog_id();
    foreach ( get_sites( [ 'number' => 0, 'fields' => 'ids' ] ) as $site_id ) {
        switch_to_blog( $site_id );
        $o6s_delete_files( (int) $site_id !== $o6s_current );
        restore_current_blog();
    }
} else {
    $o6s_delete_files( false );
}

// The deactivated plugin does not register the taxonomy. Without it, get_terms() fails
// and wp_delete_post() keeps the term relationships.
register_taxonomy( 'o6_stylesheet_cat', 'o6_stylesheet' );

// get_posts() skips trash, auto-draft and unregistered statuses.
$stylesheets = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'o6_stylesheet'" );

foreach ( $stylesheets as $post_id ) {
    wp_delete_post( $post_id, true );
}

// Delete taxonomy terms
$terms = get_terms( [
    'taxonomy'   => 'o6_stylesheet_cat',
    'hide_empty' => false,
    'fields'     => 'ids',
] );

if ( ! is_wp_error( $terms ) ) {
    foreach ( $terms as $term_id ) {
        wp_delete_term( $term_id, 'o6_stylesheet_cat' );
    }
}
delete_option( 'o6_stylesheet_cat_children' );
