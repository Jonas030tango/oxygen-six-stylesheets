<?php
/**
 * Oxygen Six Stylesheets - Admin UI
 *
 * Handles meta boxes, CodeMirror editor, admin columns, and asset enqueuing.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Admin {

    // One CSS token: the body of an unquoted url(), a comment, a string or an escape.
    // "myurl(" is another function, so an ident character before "url(" stops the url() body.
    // The regex scans left to right, so "/*" in a string or a url() does not start a comment.
    // As in the browser, a comment without "*/" runs to the end, and a string ends at a line break.
    const CSS_TOKEN_RE = '/(?<=url\()(?<![\w\x80-\xff-]url\()(?!\s*+[\'"])(?:[^)\\\\]++|\\\\.)++|\/\*[^*]*+(?:\*++[^*\/][^*]*+)*+(?:\*++\/?)?|"[^"\\\\\r\n\f]*+(?:\\\\(?:\r\n|.)[^"\\\\\r\n\f]*+)*+"?|\'[^\'\\\\\r\n\f]*+(?:\\\\(?:\r\n|.)[^\'\\\\\r\n\f]*+)*+\'?|\\\\(?:[0-9a-f]{1,6}(?:\r\n|[ \t\r\n\f])?|.)/is';

    /** Maximum size of an import file in bytes. */
    const IMPORT_MAX_SIZE = 2 * 1024 * 1024;

    /**
     * Initialize admin hooks.
     */
    public static function init() {
        // A save, a revision restore or a status change can also come through WP-CLI, XML-RPC or cron.
        add_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10, 2 );
        add_action( 'wp_restore_post_revision', [ __CLASS__, 'restore_revision' ], 10, 2 );
        add_filter( 'wp_insert_post_data', [ __CLASS__, 'no_private_status' ] );
        if ( is_admin() || ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
            self::add_css_filter();
        }
        // Cron publishes a scheduled stylesheet and can write a revision. Core publishes the post on this event at priority 10.
        add_action( 'publish_future_post', [ __CLASS__, 'add_css_filter' ], 9 );
        // The frontend can use the stored CSS before an admin request.
        add_action( 'init', [ __CLASS__, 'maybe_resanitize_css' ] );

        // is_admin() is also true for admin-ajax.php, which runs Quick Edit.
        if ( ! is_admin() ) {
            return;
        }
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_boxes' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_filter( 'manage_o6_stylesheet_posts_columns', [ __CLASS__, 'admin_columns' ] );
        add_action( 'manage_o6_stylesheet_posts_custom_column', [ __CLASS__, 'admin_column_content' ], 10, 2 );
        add_filter( 'manage_edit-o6_stylesheet_sortable_columns', [ __CLASS__, 'sortable_columns' ] );
        add_action( 'admin_notices', [ __CLASS__, 'external_url_warning' ] );
        add_filter( 'quick_edit_statuses', [ __CLASS__, 'quick_edit_statuses' ], 10, 2 );
        add_action( 'quick_edit_custom_box', [ __CLASS__, 'quick_edit_fields' ], 10, 2 );
        add_action( 'admin_footer-edit.php', [ __CLASS__, 'quick_edit_js' ] );
        add_filter( 'bulk_actions-edit-o6_stylesheet', [ __CLASS__, 'register_bulk_actions' ] );
        add_filter( 'handle_bulk_actions-edit-o6_stylesheet', [ __CLASS__, 'handle_bulk_actions' ], 10, 3 );
        add_action( 'admin_notices', [ __CLASS__, 'bulk_action_notices' ] );
        add_filter( 'removable_query_args', [ __CLASS__, 'removable_query_args' ] );
        add_action( 'admin_menu', [ __CLASS__, 'add_import_export_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'handle_import_export' ] );
        add_action( 'admin_notices', [ __CLASS__, 'css_validation_warning' ] );
        add_action( 'admin_notices', [ __CLASS__, 'css_check_notices' ] );
    }

    /**
     * Register meta boxes.
     */
    public static function add_meta_boxes() {
        add_meta_box(
            'o6s_css_editor',
            __( 'CSS Code', 'oxygen-six-stylesheets' ),
            [ __CLASS__, 'render_css_editor' ],
            'o6_stylesheet',
            'normal',
            'high'
        );

        add_meta_box(
            'o6s_settings',
            __( 'Stylesheet Settings', 'oxygen-six-stylesheets' ),
            [ __CLASS__, 'render_settings' ],
            'o6_stylesheet',
            'side',
            'high'
        );
    }

    /**
     * Render the CSS code editor meta box.
     *
     * @param \WP_Post $post
     */
    public static function render_css_editor( $post ) {
        wp_nonce_field( 'o6s_save_stylesheet', 'o6s_nonce' );
        $css = get_post_meta( $post->ID, '_o6s_css_unchecked', true );
        if ( '' !== $css ) {
            echo '<div class="notice notice-error inline"><p>'
                . esc_html__( 'The CSS check failed for this CSS after a plugin update. The site does not use this CSS. Correct it and save.', 'oxygen-six-stylesheets' )
                . '</p></div>';
        } else {
            $css = get_post_meta( $post->ID, '_o6s_css', true );
        }
        ?>
        <div class="o6s-css-editor-wrap">
            <textarea id="o6s-css-code" name="o6s_css" rows="20"><?php echo esc_textarea( $css ); ?></textarea>
        </div>
        <?php
    }

    /**
     * Render the settings meta box (active toggle + priority).
     *
     * @param \WP_Post $post
     */
    public static function render_settings( $post ) {
        $priority = get_post_meta( $post->ID, '_o6s_priority', true );

        // Default for new posts
        if ( $priority === '' ) {
            $priority = '10';
        }
        ?>
        <div class="o6s-meta-field o6s-priority-field">
            <label for="o6s-priority">
                <?php esc_html_e( 'Priority', 'oxygen-six-stylesheets' ); ?>
            </label>
            <input type="number" id="o6s-priority" name="o6s_priority" value="<?php echo esc_attr( $priority ); ?>" min="0" max="999" step="1" style="width: 80px;">
            <p class="description">
                <?php esc_html_e( 'Lower number = loads earlier. Default: 10.', 'oxygen-six-stylesheets' ); ?>
            </p>
        </div>

        <?php if ( $post->post_modified && $post->post_modified !== '0000-00-00 00:00:00' ) : ?>
        <div class="o6s-meta-field o6s-audit-info">
            <strong><?php esc_html_e( 'Last modified', 'oxygen-six-stylesheets' ); ?></strong>
            <p class="description">
                <?php
                $last_editor_id = get_post_meta( $post->ID, '_edit_last', true );
                $author = $last_editor_id ? get_userdata( $last_editor_id ) : get_userdata( $post->post_author );
                printf(
                    /* translators: %1$s: date, %2$s: username */
                    esc_html__( '%1$s by %2$s', 'oxygen-six-stylesheets' ),
                    esc_html( get_the_modified_date( '', $post ) . ' ' . get_the_modified_time( '', $post ) ),
                    $author ? esc_html( $author->display_name ) : esc_html__( 'Unknown', 'oxygen-six-stylesheets' )
                );
                ?>
            </p>
        </div>
        <?php endif; ?>
        <?php
    }

    /**
     * Save meta box data.
     *
     * @param int      $post_id
     * @param \WP_Post $post
     */
    public static function save_post( $post_id, $post ) {
        // Verify nonce — accept either full-edit or quick-edit nonce
        $full_edit_valid  = isset( $_POST['o6s_nonce'] )
            && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_nonce'] ) ), 'o6s_save_stylesheet' );
        $quick_edit_valid = isset( $_POST['o6s_quick_nonce'] )
            && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_quick_nonce'] ) ), 'o6s_quick_edit' );
        if ( ! $full_edit_valid && ! $quick_edit_valid ) {
            return;
        }

        // Check autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Check permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save CSS (full editor only). The quick-edit form carries the
        // priority field only, so the CSS body is gated on the full-edit
        // nonce — the quick-edit path must never write CSS. is_string()
        // guards against a crafted o6s_css[] array being stored as meta and
        // later fataling a frontend trim() call.
        if ( $full_edit_valid && isset( $_POST['o6s_css'] ) && is_string( $_POST['o6s_css'] ) ) {
            $css = self::sanitize_css_on_save( wp_unslash( $_POST['o6s_css'] ) );
            if ( null === $css ) {
                add_filter( 'redirect_post_location', function ( $location ) {
                    return add_query_arg( 'o6s_css_failed', 1, $location );
                } );
            }
        }
        // NULL: the check failed, so the stored CSS stays.
        if ( isset( $css ) ) {
            // The WordPress write functions unslash their input. wp_slash() keeps CSS escapes such as \201C.
            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );
            delete_post_meta( $post_id, '_o6s_css_unchecked' );

            // Also store in post_content so WordPress revisions track CSS changes.
            // We unhook save_post first to prevent infinite loop.
            remove_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10 );
            wp_update_post( wp_slash( [
                'ID'           => $post_id,
                'post_content' => $css,
            ] ) );
            add_action( 'save_post_o6_stylesheet', [ __CLASS__, 'save_post' ], 10, 2 );
        }

        // Save priority
        if ( isset( $_POST['o6s_priority'] ) ) {
            $priority = absint( wp_unslash( $_POST['o6s_priority'] ) );
            update_post_meta( $post_id, '_o6s_priority', $priority );
        }
    }

    /**
     * Sanitize CSS content on save.
     *
     * @param string $css Raw CSS input.
     * @return string|null Sanitized CSS. NULL if a regex fails: do not store or show the CSS.
     */
    public static function sanitize_css_on_save( $css ) {
        $binding  = self::css_word_regex( '-moz-binding', true );
        $behavior = self::css_word_regex( 'behavior', true );
        return preg_replace(
            [
                // @import can load an external stylesheet and leak data.
                self::css_word_regex( '@import' ),
                self::css_word_regex( 'expression(' ),
                $binding,
                $behavior,
                self::css_word_regex( 'javascript:' ),
                // Replace each tag start to prevent XSS breakout inside <style>.
                // Keep "(?<!<)<+". Developement/Testing/sanitize-css-check.php tests it.
                '/(?<!<)<+[a-z\/!]/i',
                // The marker from the step before can come before a property name.
                $binding,
                $behavior,
            ],
            // A comment as a marker can hide the next rules. The browser ignores the unknown at-rule up to its ";".
            [ '@o6s-removed-import', '[removed](', '[removed]:', '[removed]:', '[removed]:', '[removed]', '[removed]:', '[removed]:' ],
            $css
        );
    }

    /**
     * Build a regex that matches $word case-insensitively.
     * Each character also matches its CSS escape (\65, \000045 , \x), because the browser decodes escapes.
     * Whitespace and a backslash before whitespace can separate the characters.
     *
     * @param string $word     ASCII text.
     * @param bool   $property Also match a colon after $word. A comment can come before the colon.
     * @return string
     */
    private static function css_word_regex( $word, $property = false ) {
        $chars = [];
        foreach ( str_split( $word ) as $c ) {
            $codes = array_unique( [ dechex( ord( strtolower( $c ) ) ), dechex( ord( strtoupper( $c ) ) ) ] );
            // A hex escape has at most 6 digits and ends at the first non-hex character or at one whitespace.
            $alt = preg_quote( $c, '/' ) . '|\\\\0{0,4}(?:' . implode( '|', $codes ) . ')(?![0-9a-f])(?:\r\n|[ \t\r\n\f])?';
            // "\e" is the hex escape U+000E, not "e".
            if ( ! ctype_xdigit( $c ) ) {
                $alt .= '|\\\\' . preg_quote( $c, '/' );
            }
            $chars[] = '(?:' . $alt . ')';
        }
        // Each repetition of a group counts toward pcre.backtrack_limit, so a whitespace run must not repeat a group.
        $re = implode( '\s*+(?:\\\\\s\s*+)*+', $chars );
        if ( $property ) {
            // An ident character before $word makes a longer name, for example "scroll-behavior". "." and "#" start a selector.
            $re  = '(?<![a-z0-9_\-\\\\\x80-\xff.#])' . $re;
            $re .= '\s*+(?:(?:\\\\\s|\/\*[^*]*+\*++(?:[^\/*][^*]*+\*++)*+\/)\s*+)*+:';
        }
        return '/' . $re . '/i';
    }

    /**
     * After a plugin update, sanitize the stored CSS again with the current rules.
     * sanitize_css_output() removes only tag starts.
     */
    public static function maybe_resanitize_css() {
        $version = get_option( 'o6s_css_version' );
        if ( $version === O6S_VERSION ) {
            return;
        }
        global $wpdb;
        $ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'o6_stylesheet'" );
        foreach ( $ids as $id ) {
            $old = get_post_meta( $id, '_o6s_css', true );
            $css = $old;
            // Without the option, the CSS comes from the old sanitizer.
            // Only here: the current tag step can make "/* [removed] */" from a comment such as "/* <a */".
            if ( false === $version && is_string( $css ) ) {
                $css = str_replace(
                    [ '/* [removed:import] */', '/* [removed] */', '/* [removed] (', '/* [removed] :' ],
                    [ '@o6s-removed-import', '[removed]', '[removed](', '[removed]:' ],
                    $css
                );
            }
            $clean = is_string( $css ) ? self::sanitize_css_on_save( $css ) : '';
            if ( null === $clean ) {
                // A stylesheet of any status can go live without a save. The frontend reads only _o6s_css.
                update_post_meta( $id, '_o6s_css_unchecked', wp_slash( $css ) );
                $clean = '';
            }
            if ( $clean !== $old ) {
                update_post_meta( $id, '_o6s_css', wp_slash( $clean ) );
            }
        }
        // Older versions let Quick Edit and Bulk Edit set these. See no_private_status().
        if ( $wpdb->query( "UPDATE {$wpdb->posts} SET post_status = IF( post_status = 'private', 'draft', post_status ), post_password = '' WHERE post_type = 'o6_stylesheet' AND ( post_status = 'private' OR post_password <> '' )" ) ) {
            array_map( 'clean_post_cache', $ids );
            // The raw UPDATE skips the status hook that clears the post counts.
            wp_cache_delete( _count_posts_cache_key( 'o6_stylesheet' ), 'counts' );
            wp_cache_delete( _count_posts_cache_key( 'o6_stylesheet', 'readable' ), 'counts' );
        }
        // css_check_notices() looks for _o6s_css_unchecked only while this flag exists.
        // Set the flag on each run: an older version wrote the meta without it.
        update_option( 'o6s_css_unchecked', '1', true );
        // Set the option last. A request that stops early runs the update again.
        update_option( 'o6s_css_version', O6S_VERSION, true );
    }

    public static function css_check_notices() {
        $post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
        // save_post checks edit_post, not edit_o6_stylesheets.
        if ( isset( $_GET['o6s_css_failed'] ) && 'o6_stylesheet' === get_post_type( $post_id ) && current_user_can( 'edit_post', $post_id ) ) {
            echo '<div class="notice notice-error is-dismissible"><p>'
                . esc_html__( 'CSS not saved: the CSS check failed. The previous CSS stays.', 'oxygen-six-stylesheets' )
                . '</p></div>';
        }
        if ( ! isset( wp_load_alloptions()['o6s_css_unchecked'] ) || ! current_user_can( 'edit_o6_stylesheets' ) ) {
            return;
        }
        global $wpdb;
        // The trash keeps the flag: an untrashed stylesheet must show the notice again.
        $rows = $wpdb->get_results(
            "SELECT DISTINCT p.ID, p.post_status, p.post_date FROM {$wpdb->posts} AS p
            INNER JOIN {$wpdb->postmeta} AS m ON ( m.post_id = p.ID AND m.meta_key = '_o6s_css_unchecked' )
            WHERE p.post_type = 'o6_stylesheet'
            ORDER BY p.post_date DESC"
        );
        if ( ! $rows && $wpdb->last_error === '' ) {
            delete_option( 'o6s_css_unchecked' );
            return;
        }
        $links = [];
        foreach ( $rows as $row ) {
            $id = (int) $row->ID;
            if ( ! in_array( $row->post_status, [ 'trash', 'auto-draft' ], true ) && current_user_can( 'edit_post', $id ) ) {
                $links[] = '<a href="' . esc_url( (string) get_edit_post_link( $id ) ) . '">' . _draft_or_post_title( $id ) . '</a>';
            }
        }
        if ( ! $links ) {
            return;
        }
        echo '<div class="notice notice-warning"><p>'
            . esc_html__( 'The CSS check failed after a plugin update. The site does not use the CSS of these stylesheets. Correct the CSS and save:', 'oxygen-six-stylesheets' )
            . ' ' . implode( ', ', $links ) . '</p></div>';
    }

    /**
     * Register keep_css_in_post_content() for the current request.
     */
    public static function add_css_filter() {
        add_filter( 'wp_insert_post_data', [ __CLASS__, 'keep_css_in_post_content' ], 10, 3 );
    }

    /**
     * Replace kses with the CSS sanitizer for the post_content of a stylesheet and its revisions.
     * Without unfiltered_html, kses changes `a > b` to `a &gt; b`. A revision restore then copies that into the CSS.
     *
     * @param array $data                Slashed post data after the sanitize filters.
     * @param array $postarr
     * @param array $unsanitized_postarr Slashed post data before the sanitize filters.
     * @return array
     */
    public static function keep_css_in_post_content( $data, $postarr = [], $unsanitized_postarr = null ) {
        if ( ! is_array( $data ) || ! isset( $data['post_type'] )
            || ( $data['post_type'] !== 'o6_stylesheet' && $data['post_type'] !== 'revision' )
            || ! has_filter( 'content_save_pre', 'wp_filter_post_kses' )
            || ! is_array( $unsanitized_postarr )
            || ! isset( $unsanitized_postarr['post_content'] )
            || ! is_string( $unsanitized_postarr['post_content'] ) ) {
            return $data;
        }
        $type = $data['post_type'] === 'revision' ? get_post_type( $data['post_parent'] ?? 0 ) : $data['post_type'];
        if ( $type !== 'o6_stylesheet' ) {
            return $data;
        }
        $css = self::sanitize_css_on_save( wp_unslash( $unsanitized_postarr['post_content'] ) );
        // NULL: the kses output stays. The frontend does not show post_content, and restore_revision() checks it again.
        if ( null !== $css ) {
            $data['post_content'] = wp_slash( $css );
        }
        return $data;
    }

    /**
     * A stylesheet is never private or password-protected. The frontend loads only published stylesheets,
     * and the edit screen hides the Visibility row, so a private stylesheet cannot go back.
     *
     * @param array $data Slashed post data.
     * @return array
     */
    public static function no_private_status( $data ) {
        if ( is_array( $data ) && ( $data['post_type'] ?? '' ) === 'o6_stylesheet' ) {
            if ( ( $data['post_status'] ?? '' ) === 'private' ) {
                $data['post_status'] = 'draft';
            }
            $data['post_password'] = '';
        }
        return $data;
    }

    /**
     * Remove Private from the Bulk Edit status list. The filter exists since WordPress 6.9.
     *
     * @param array  $statuses
     * @param string $post_type
     * @return array
     */
    public static function quick_edit_statuses( $statuses, $post_type ) {
        if ( 'o6_stylesheet' === $post_type ) {
            unset( $statuses['private'] );
        }
        return $statuses;
    }

    /**
     * When a revision is restored, sync post_content back to _o6s_css meta.
     *
     * @param int $post_id     The post ID being restored to.
     * @param int $revision_id The revision ID being restored.
     */
    public static function restore_revision( $post_id, $revision_id ) {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $revision = get_post( $revision_id );
        $css = $revision ? self::sanitize_css_on_save( $revision->post_content ) : null;
        if ( null !== $css ) {
            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );
            delete_post_meta( $post_id, '_o6s_css_unchecked' );
        }
    }

    /**
     * Show admin notice if the current stylesheet contains external url() references.
     */
    public static function external_url_warning() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' || $screen->base !== 'post' ) {
            return;
        }

        global $post;
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $css = get_post_meta( $post->ID, '_o6s_css', true );
        if ( empty( $css ) ) {
            return;
        }

        if ( self::has_external_url( $css ) ) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <strong><?php esc_html_e( 'Security Notice', 'oxygen-six-stylesheets' ); ?>:</strong>
                    <?php esc_html_e( 'This stylesheet contains external url() references. External URLs can load resources from third-party servers and may be used for data exfiltration via CSS attribute selectors. Only use trusted domains.', 'oxygen-six-stylesheets' ); ?>
                </p>
            </div>
            <?php
        }
    }

    /**
     * Find a reference to an external URL.
     * The check deletes comments and decodes the escapes of URL characters.
     * The URL parser reads "\" as "/" and deletes tabs and line breaks.
     *
     * @param string $css
     * @return bool TRUE also if a regex fails.
     */
    public static function has_external_url( $css ) {
        $url_chars = [ '\\' => '/', "\r" => '', "\n" => '' ];
        $found     = false;
        $css       = preg_replace_callback(
            self::CSS_TOKEN_RE,
            function ( $token ) use ( $url_chars, &$found ) {
                if ( '/*' === substr( $token[0], 0, 2 ) ) {
                    return ' ';
                }
                $token = preg_replace_callback(
                    '/\\\\(?:([0-9a-f]{1,6})(?:\r\n|[ \t\r\n\f])?|(\r\n|[^0-9a-f]))/i',
                    function ( $e ) use ( $url_chars ) {
                        // A backslash before a line break is a line continuation.
                        if ( isset( $e[2] ) && '' === trim( $e[2], "\r\n\f" ) ) {
                            return '';
                        }
                        $c = isset( $e[2] ) ? $e[2] : ( hexdec( $e[1] ) < 128 ? chr( hexdec( $e[1] ) ) : '' );
                        return preg_match( '/^[a-z:\/\\\\ \t\r\n]\z/i', $c ) ? strtr( $c, $url_chars ) : $e[0];
                    },
                    $token[0]
                );
                $token = strtr( $token, [ "\t" => '' ] );
                // url(""), image-set() and @import take a string.
                $found = $found || preg_match( '/^[\'"][\x00-\x20]*+(?:https?:|\/\/)\/*+[^\s\/\'"]/i', $token );
                return $token;
            },
            $css
        );
        return null === $css || $found || 0 !== preg_match( '/url\(\s*+(?:https?:|\/\/)/i', $css );
    }

    /**
     * Enqueue CodeMirror and admin CSS on stylesheet edit screens.
     *
     * @param string $hook
     */
    public static function enqueue_assets( $hook ) {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' ) {
            return;
        }

        // Admin list and edit styles
        wp_enqueue_style(
            'o6s-admin',
            O6S_PLUGIN_URL . 'assets/css/admin.css',
            [],
            O6S_VERSION
        );

        // On edit screens: CodeMirror + hide visibility options
        if ( $hook === 'post.php' || $hook === 'post-new.php' ) {
            // Hide visibility option -- stylesheets are always public
            wp_add_inline_style( 'o6s-admin', '#visibility { display: none; }' );

            $cm_settings = wp_enqueue_code_editor( [ 'type' => 'text/css' ] );

            if ( $cm_settings !== false ) {
                wp_add_inline_script(
                    'code-editor',
                    sprintf(
                        'jQuery(function($) {
                            if ($("#o6s-css-code").length) {
                                var editor = wp.codeEditor.initialize($("#o6s-css-code"), %s);
                                // Auto-resize
                                editor.codemirror.on("change", function(cm) {
                                    cm.refresh();
                                });
                            }
                        });',
                        wp_json_encode( $cm_settings )
                    )
                );
            }
        }
    }

    /**
     * Add custom admin columns.
     *
     * @param array $columns
     * @return array
     */
    public static function admin_columns( $columns ) {
        $new_columns = [];
        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;
            if ( $key === 'title' ) {
                $new_columns['o6s_active']   = __( 'Active', 'oxygen-six-stylesheets' );
                $new_columns['o6s_priority'] = __( 'Priority', 'oxygen-six-stylesheets' );
                $new_columns['o6s_size']     = __( 'CSS Size', 'oxygen-six-stylesheets' );
            }
        }
        return $new_columns;
    }

    /**
     * Render custom admin column content.
     *
     * @param string $column
     * @param int    $post_id
     */
    public static function admin_column_content( $column, $post_id ) {
        switch ( $column ) {
            case 'o6s_active':
                $is_active = ( get_post_status( $post_id ) === 'publish' );
                echo $is_active
                    ? '<span class="o6s-status-dot o6s-status-dot--active" title="' . esc_attr__( 'Active', 'oxygen-six-stylesheets' ) . '"></span> ' . esc_html__( 'Active', 'oxygen-six-stylesheets' )
                    : '<span class="o6s-status-dot o6s-status-dot--inactive" title="' . esc_attr__( 'Inactive', 'oxygen-six-stylesheets' ) . '"></span> ' . esc_html__( 'Inactive', 'oxygen-six-stylesheets' );
                break;

            case 'o6s_priority':
                $priority = get_post_meta( $post_id, '_o6s_priority', true );
                echo esc_html( $priority !== '' ? $priority : '10' );
                break;

            case 'o6s_size':
                $css = get_post_meta( $post_id, '_o6s_css', true );
                if ( ! empty( $css ) ) {
                    $bytes = strlen( $css );
                    if ( $bytes >= 1024 ) {
                        echo esc_html( round( $bytes / 1024, 1 ) . ' KB' );
                    } else {
                        echo esc_html( $bytes . ' B' );
                    }
                } else {
                    echo '<span class="description">' . esc_html__( 'Empty', 'oxygen-six-stylesheets' ) . '</span>';
                }
                break;
        }
    }

    /**
     * Make columns sortable.
     *
     * @param array $columns
     * @return array
     */
    public static function sortable_columns( $columns ) {
        $columns['o6s_priority'] = 'o6s_priority';
        return $columns;
    }

    /**
     * Add active toggle and priority field to quick-edit.
     *
     * @param string $column_name
     * @param string $post_type
     */
    public static function quick_edit_fields( $column_name, $post_type ) {
        if ( $post_type !== 'o6_stylesheet' || $column_name !== 'o6s_active' ) {
            return;
        }
        wp_nonce_field( 'o6s_quick_edit', 'o6s_quick_nonce' );
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label class="inline-edit-group">
                    <span class="title"><?php esc_html_e( 'Priority', 'oxygen-six-stylesheets' ); ?></span>
                    <input type="number" name="o6s_priority" min="0" max="999" step="1" style="width: 60px;">
                </label>
            </div>
        </fieldset>
        <?php
    }

    /**
     * JavaScript to populate quick-edit fields with current values.
     */
    public static function quick_edit_js() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' ) {
            return;
        }
        ?>
        <script>
        jQuery(function($) {
            var origInlineEdit = inlineEditPost.edit;
            inlineEditPost.edit = function(id) {
                origInlineEdit.apply(this, arguments);
                var postId = 0;
                if (typeof id === 'object') {
                    postId = parseInt(this.getId(id));
                }
                if (postId > 0) {
                    var row = $('#post-' + postId);
                    var priority = row.find('.column-o6s_priority').text().trim();
                    var editRow = $('#edit-' + postId);
                    editRow.find('input[name="o6s_priority"]').val(priority);
                }
            };
        });
        </script>
        <?php
    }

    /**
     * Register custom bulk actions.
     *
     * @param array $actions
     * @return array
     */
    public static function register_bulk_actions( $actions ) {
        if ( current_user_can( 'publish_o6_stylesheets' ) ) {
            $actions['o6s_activate'] = __( 'Activate', 'oxygen-six-stylesheets' );
        }
        $actions['o6s_deactivate'] = __( 'Deactivate', 'oxygen-six-stylesheets' );
        return $actions;
    }

    /**
     * Handle custom bulk actions.
     *
     * @param string $redirect_url
     * @param string $action
     * @param array  $post_ids
     * @return string
     */
    public static function handle_bulk_actions( $redirect_url, $action, $post_ids ) {
        if ( $action !== 'o6s_activate' && $action !== 'o6s_deactivate' ) {
            return $redirect_url;
        }

        $new_status = ( $action === 'o6s_activate' ) ? 'publish' : 'draft';
        $count = 0;

        // wp_update_post() checks no capability.
        if ( $action === 'o6s_activate' && ! current_user_can( 'publish_o6_stylesheets' ) ) {
            return $redirect_url;
        }

        foreach ( $post_ids as $post_id ) {
            // Skip unchanged posts: an update of a draft resets its date.
            // Skip trashed posts: only an untrash restores them correctly.
            if ( get_post_type( $post_id ) !== 'o6_stylesheet'
                || in_array( get_post_status( $post_id ), [ $new_status, 'trash' ], true )
                || ! current_user_can( 'edit_post', $post_id ) ) {
                continue;
            }
            wp_update_post( [ 'ID' => $post_id, 'post_status' => $new_status ] );
            // A post with a future date becomes `future` and does not count.
            if ( get_post_status( $post_id ) === $new_status ) {
                $count++;
            }
        }

        return add_query_arg( [
            'o6s_bulk_action' => $action,
            'o6s_bulk_count'  => $count,
        ], $redirect_url );
    }

    /**
     * Add the notice args to the core list, so a reload does not show the notice again.
     *
     * @param array $args
     * @return array
     */
    public static function removable_query_args( $args ) {
        $args[] = 'o6s_bulk_action';
        $args[] = 'o6s_bulk_count';
        $args[] = 'o6s_css_failed';
        return $args;
    }

    /**
     * Show admin notice after bulk action.
     */
    public static function bulk_action_notices() {
        if ( ! isset( $_GET['o6s_bulk_action'] ) || ! isset( $_GET['o6s_bulk_count'] ) ) {
            return;
        }

        $action = sanitize_text_field( wp_unslash( $_GET['o6s_bulk_action'] ) );
        $count  = absint( wp_unslash( $_GET['o6s_bulk_count'] ) );

        if ( $action === 'o6s_activate' ) {
            $message = sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d stylesheet activated.', '%d stylesheets activated.', $count, 'oxygen-six-stylesheets' ),
                $count
            );
        } elseif ( $action === 'o6s_deactivate' ) {
            $message = sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d stylesheet deactivated.', '%d stylesheets deactivated.', $count, 'oxygen-six-stylesheets' ),
                $count
            );
        } else {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
    }

    /**
     * Validate CSS and return an array of warning messages.
     *
     * @param string $css The CSS to validate.
     * @return string[] Array of warning messages (empty if valid).
     */
    public static function validate_css( $css ) {
        $warnings = [];

        if ( empty( trim( $css ) ) ) {
            return $warnings;
        }

        $stripped = preg_replace( self::CSS_TOKEN_RE, ' ', $css );
        if ( null === $stripped ) {
            return [ __( 'The CSS is too large or too complex to check.', 'oxygen-six-stylesheets' ) ];
        }

        // Check for unbalanced braces
        $open  = substr_count( $stripped, '{' );
        $close = substr_count( $stripped, '}' );
        if ( $open !== $close ) {
            $warnings[] = sprintf(
                /* translators: %1$d: opening braces, %2$d: closing braces */
                __( 'Unbalanced braces: %1$d opening { vs %2$d closing }.', 'oxygen-six-stylesheets' ),
                $open,
                $close
            );
        }

        // Check for unbalanced parentheses
        $open_parens  = substr_count( $stripped, '(' );
        $close_parens = substr_count( $stripped, ')' );
        if ( $open_parens !== $close_parens ) {
            $warnings[] = sprintf(
                /* translators: %1$d: opening parens, %2$d: closing parens */
                __( 'Unbalanced parentheses: %1$d opening ( vs %2$d closing ).', 'oxygen-six-stylesheets' ),
                $open_parens,
                $close_parens
            );
        }

        // Check for empty rule blocks
        if ( preg_match( '/\{[\s]*\}/', $stripped ) ) {
            $warnings[] = __( 'Empty rule block detected (a selector with no properties).', 'oxygen-six-stylesheets' );
        }

        return $warnings;
    }

    /**
     * Show CSS validation warnings on the edit screen.
     */
    public static function css_validation_warning() {
        $screen = get_current_screen();
        if ( ! $screen || $screen->post_type !== 'o6_stylesheet' || $screen->base !== 'post' ) {
            return;
        }

        global $post;
        if ( ! $post || $post->post_type !== 'o6_stylesheet' ) {
            return;
        }

        $css = get_post_meta( $post->ID, '_o6s_css', true );
        if ( empty( $css ) ) {
            return;
        }

        $warnings = self::validate_css( $css );
        if ( empty( $warnings ) ) {
            return;
        }

        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>' . esc_html__( 'CSS Validation', 'oxygen-six-stylesheets' ) . ':</strong></p>';
        echo '<ul style="list-style: disc; padding-left: 20px;">';
        foreach ( $warnings as $warning ) {
            echo '<li>' . esc_html( $warning ) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }

    /**
     * Register the Import/Export submenu page.
     */
    public static function add_import_export_page() {
        add_submenu_page(
            'edit.php?post_type=o6_stylesheet',
            __( 'Import / Export', 'oxygen-six-stylesheets' ),
            __( 'Import / Export', 'oxygen-six-stylesheets' ),
            'manage_options',
            'o6s-import-export',
            [ __CLASS__, 'render_import_export_page' ]
        );
    }

    /**
     * Render the Import/Export page.
     */
    public static function render_import_export_page() {
        $import_result = get_transient( 'o6s_import_result' );
        if ( $import_result ) {
            delete_transient( 'o6s_import_result' );
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Import / Export Stylesheets', 'oxygen-six-stylesheets' ); ?></h1>

            <?php if ( $import_result ) : ?>
                <div class="notice notice-<?php echo esc_attr( $import_result['type'] ?? 'error' ); ?> is-dismissible">
                    <p><?php echo esc_html( $import_result['message'] ); ?></p>
                </div>
            <?php endif; ?>

            <div class="card" style="max-width: 600px; margin-bottom: 20px;">
                <h2><?php esc_html_e( 'Export', 'oxygen-six-stylesheets' ); ?></h2>
                <p><?php esc_html_e( 'Download all stylesheets as a JSON file. Includes CSS, active status, priority, and categories.', 'oxygen-six-stylesheets' ); ?></p>
                <form method="post">
                    <?php wp_nonce_field( 'o6s_export', 'o6s_export_nonce' ); ?>
                    <input type="hidden" name="o6s_action" value="export">
                    <?php submit_button( __( 'Export Stylesheets', 'oxygen-six-stylesheets' ), 'primary', 'o6s_export_submit', false ); ?>
                </form>
            </div>

            <div class="card" style="max-width: 600px;">
                <h2><?php esc_html_e( 'Import', 'oxygen-six-stylesheets' ); ?></h2>
                <p><?php esc_html_e( 'Upload a previously exported JSON file. Existing stylesheets with the same title will be skipped.', 'oxygen-six-stylesheets' ); ?></p>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'o6s_import', 'o6s_import_nonce' ); ?>
                    <input type="hidden" name="o6s_action" value="import">
                    <p>
                        <input type="file" name="o6s_import_file" id="o6s-import-file" accept=".json" required>
                    </p>
                    <script>
                    // The server does the same checks.
                    document.getElementById( 'o6s-import-file' ).addEventListener( 'change', function () {
                        var file = this.files[0];
                        var msg  = '';
                        if ( file && ! /\.json$/i.test( file.name ) ) {
                            msg = <?php echo wp_json_encode( __( 'The file must be a .json file.', 'oxygen-six-stylesheets' ) ); ?>;
                        } else if ( file && file.size > <?php echo (int) self::IMPORT_MAX_SIZE; ?> ) {
                            msg = <?php echo wp_json_encode( __( 'Import file too large (max 2 MB).', 'oxygen-six-stylesheets' ) ); ?>;
                        }
                        this.setCustomValidity( msg );
                    } );
                    </script>
                    <?php submit_button( __( 'Import Stylesheets', 'oxygen-six-stylesheets' ), 'secondary', 'o6s_import_submit', false ); ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Handle import/export form submissions.
     */
    public static function handle_import_export() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // A request larger than post_max_size arrives with an empty $_POST and $_FILES.
        if ( ! isset( $_POST['o6s_action'] )
            && 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' )
            && 'o6s-import-export' === ( $_GET['page'] ?? '' )
            && ! empty( $_SERVER['CONTENT_LENGTH'] ) ) {
            self::set_import_result( 'error', self::server_limit_message( ini_get( 'post_max_size' ) ) );
            wp_safe_redirect( admin_url( 'edit.php?post_type=o6_stylesheet&page=o6s-import-export' ) );
            exit;
        }

        if ( ! isset( $_POST['o6s_action'] ) ) {
            return;
        }

        $action = sanitize_text_field( wp_unslash( $_POST['o6s_action'] ) );

        if ( $action === 'export' ) {
            self::do_export();
        } elseif ( $action === 'import' ) {
            self::do_import();
            // A reload of the result page must not send the file again.
            wp_safe_redirect( admin_url( 'edit.php?post_type=o6_stylesheet&page=o6s-import-export' ) );
            exit;
        }
    }

    /**
     * Export all stylesheets as JSON.
     */
    private static function do_export() {
        if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_export_nonce'] ?? '' ) ), 'o6s_export' ) ) {
            return;
        }

        $stylesheets = get_posts( [
            'post_type'      => 'o6_stylesheet',
            'posts_per_page' => -1,
            'post_status'    => 'any',
        ] );

        $export_data = [
            'plugin'  => 'oxygen-six-stylesheets',
            'version' => O6S_VERSION,
            'date'    => current_time( 'mysql' ),
            'items'   => [],
        ];

        foreach ( $stylesheets as $sheet ) {
            $categories = wp_get_object_terms( $sheet->ID, 'o6_stylesheet_cat', [ 'fields' => 'names' ] );
            $priority   = get_post_meta( $sheet->ID, '_o6s_priority', true );

            $export_data['items'][] = [
                'title'      => $sheet->post_title,
                // Import checks the CSS again.
                'css'        => get_post_meta( $sheet->ID, '_o6s_css_unchecked', true ) ?: get_post_meta( $sheet->ID, '_o6s_css', true ),
                'active'     => ( $sheet->post_status === 'publish' ) ? '1' : '0',
                'priority'   => $priority !== '' ? $priority : '10',
                'categories' => is_wp_error( $categories ) ? [] : $categories,
                'status'     => $sheet->post_status,
            ];
        }

        $filename = 'o6s-stylesheets-' . gmdate( 'Y-m-d' ) . '.json';
        header( 'Content-Type: application/json' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        echo wp_json_encode( $export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
        exit;
    }

    /**
     * Import stylesheets from JSON file.
     */
    private static function do_import() {
        if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['o6s_import_nonce'] ?? '' ) ), 'o6s_import' ) ) {
            self::set_import_result( 'error', __( 'Import failed: the form expired. Load the page again and import the file again.', 'oxygen-six-stylesheets' ) );
            return;
        }

        // wp_insert_post() checks no capability.
        if ( ! current_user_can( 'edit_o6_stylesheets' ) ) {
            self::set_import_result( 'error', __( 'Import failed: you are not allowed to create stylesheets.', 'oxygen-six-stylesheets' ) );
            return;
        }

        $file  = $_FILES['o6s_import_file'] ?? [];
        $error = (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE );
        if ( UPLOAD_ERR_NO_FILE === $error ) {
            self::set_import_result( 'error', __( 'No file selected.', 'oxygen-six-stylesheets' ) );
            return;
        }

        if ( UPLOAD_ERR_INI_SIZE === $error ) {
            self::set_import_result( 'error', self::server_limit_message( ini_get( 'upload_max_filesize' ) ) );
            return;
        }

        // Limit import file size to 2 MB to prevent memory exhaustion
        if ( ( $file['size'] ?? 0 ) > self::IMPORT_MAX_SIZE ) {
            self::set_import_result( 'error', __( 'Import file too large (max 2 MB).', 'oxygen-six-stylesheets' ) );
            return;
        }

        if ( UPLOAD_ERR_OK !== $error || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
            self::set_import_result( 'error', sprintf(
                /* translators: %d: PHP upload error code */
                __( 'Import failed: the upload did not complete (PHP upload error %d).', 'oxygen-six-stylesheets' ),
                $error
            ) );
            return;
        }

        if ( 'json' !== strtolower( pathinfo( (string) ( $file['name'] ?? '' ), PATHINFO_EXTENSION ) ) ) {
            self::set_import_result( 'error', __( 'Import failed: the file must be a .json file.', 'oxygen-six-stylesheets' ) );
            return;
        }

        $data = json_decode( file_get_contents( $file['tmp_name'] ), true );

        if ( JSON_ERROR_NONE !== json_last_error() ) {
            self::set_import_result( 'error', sprintf(
                /* translators: %s: JSON parser error, for example "Syntax error" */
                __( 'Import failed: the file is not valid JSON (%s).', 'oxygen-six-stylesheets' ),
                json_last_error_msg()
            ) );
            return;
        }

        if ( ! is_array( $data ) || ! isset( $data['items'] ) || ! is_array( $data['items'] ) ) {
            self::set_import_result( 'error', __( 'Import failed: the file is not a stylesheet export. The "items" list is missing.', 'oxygen-six-stylesheets' ) );
            return;
        }

        $imported   = 0;
        $duplicates = 0;
        $invalid    = 0;
        $failed     = 0;
        $unchecked  = 0;

        // The SQL name match of get_terms() matches "ä" to "a".
        $cat_map = get_terms( [ 'taxonomy' => 'o6_stylesheet_cat', 'hide_empty' => false, 'fields' => 'id=>name' ] );
        $cat_map = is_array( $cat_map ) ? $cat_map : [];

        foreach ( $data['items'] as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['title'] ) || ! is_string( $item['title'] ) ) {
                $invalid++;
                continue;
            }

            // unfiltered_html skips kses, so the import strips the tags itself.
            // Encode each "<" that starts no tag first: strip_tags() deletes "<3 CSS", and kses turns "< b >" into a tag.
            $title = trim( wp_strip_all_tags( preg_replace( '/<(?![a-z\/!?])/i', '&lt;', $item['title'] ) ) );
            if ( '' === $title ) {
                $invalid++;
                continue;
            }

            // A stored title can differ by kses or by outer spaces, so each form counts.
            // Titles from before the tag strip can contain tags, so the raw forms count too.
            // The default collation matches "ä" to "a" and "ß" to "ss", so PHP compares the exact title.
            global $wpdb;
            // Core trims the slashed title, so a NUL byte at the end stays.
            $trimmed    = wp_unslash( trim( wp_slash( $item['title'] ) ) );
            $candidates = array_values( array_unique( [
                $title,
                wp_unslash( sanitize_post_field( 'post_title', wp_slash( $title ), 0, 'db' ) ),
                $item['title'],
                $trimmed,
                wp_kses( $title, 'title_save_pre' ),
            ] ) );
            $skip_stati = array_values( get_post_stati( [ 'exclude_from_search' => true ] ) );
            $found      = $wpdb->get_col( $wpdb->prepare(
                "SELECT post_title FROM {$wpdb->posts} WHERE post_type = 'o6_stylesheet' AND post_status NOT IN ( "
                    . implode( ', ', array_fill( 0, count( $skip_stati ), '%s' ) ) . ' ) AND post_title IN ( '
                    . implode( ', ', array_fill( 0, count( $candidates ), '%s' ) ) . ' )',
                array_merge( $skip_stati, $candidates )
            ) );

            if ( array_intersect( $candidates, $found ) ) {
                $duplicates++;
                continue;
            }

            $css = isset( $item['css'] ) && is_string( $item['css'] ) ? $item['css'] : '';
            $css = self::sanitize_css_on_save( $css );
            if ( null === $css ) {
                $unchecked++;
                continue;
            }

            // Determine post status: honor 'active' field for backward compat,
            // fall back to 'status' field, default to publish.
            if ( isset( $item['active'] ) && $item['active'] === '0' ) {
                $status = 'draft';
            } else {
                $allowed_statuses = [ 'publish', 'draft', 'pending' ];
                $status = isset( $item['status'] ) && in_array( $item['status'], $allowed_statuses, true )
                    ? $item['status']
                    : 'publish';
            }
            if ( $status === 'publish' && ! current_user_can( 'publish_o6_stylesheets' ) ) {
                $status = 'draft';
            }

            $post_id = wp_insert_post( wp_slash( [
                'post_type'    => 'o6_stylesheet',
                'post_title'   => $title,
                'post_content' => $css,
                'post_status'  => $status,
            ] ) );

            if ( ! $post_id || is_wp_error( $post_id ) ) {
                $failed++;
                continue;
            }

            update_post_meta( $post_id, '_o6s_css', wp_slash( $css ) );
            update_post_meta( $post_id, '_o6s_priority', isset( $item['priority'] ) ? absint( $item['priority'] ) : 10 );

            // Assign categories
            if ( ! empty( $item['categories'] ) && is_array( $item['categories'] ) ) {
                $term_ids = [];
                foreach ( $item['categories'] as $cat_name ) {
                    if ( ! is_string( $cat_name ) || '' === trim( $cat_name ) ) {
                        continue;
                    }
                    // The term name filters are not idempotent, so the exported name and its filtered form both count.
                    // The last lookup ignores ASCII case, like the duplicate rule of wp_insert_term(), but at any level.
                    $name    = wp_unslash( sanitize_term_field( 'name', wp_slash( $cat_name ), 0, 'o6_stylesheet_cat', 'db' ) );
                    $term_id = (int) array_search( $cat_name, $cat_map, true )
                        ?: (int) array_search( $name, $cat_map, true )
                        ?: (int) array_search( strtolower( $name ), array_map( 'strtolower', $cat_map ), true );
                    if ( ! $term_id ) {
                        $result = wp_insert_term( wp_slash( $cat_name ), 'o6_stylesheet_cat' );
                        if ( ! is_wp_error( $result ) ) {
                            $term_id             = $result['term_id'];
                            $cat_map[ $term_id ] = $name;
                        } elseif ( 'term_exists' === $result->get_error_code() ) {
                            $term_id = (int) $result->get_error_data();
                        }
                    }
                    if ( $term_id ) {
                        $term_ids[] = $term_id;
                    }
                }
                if ( ! empty( $term_ids ) ) {
                    wp_set_object_terms( $post_id, $term_ids, 'o6_stylesheet_cat' );
                }
            }

            $imported++;
        }

        $message = sprintf(
            /* translators: %d: number of stylesheets */
            _n( '%d stylesheet imported.', '%d stylesheets imported.', $imported, 'oxygen-six-stylesheets' ),
            $imported
        );
        if ( $duplicates ) {
            $message .= ' ' . sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d skipped: a stylesheet with the same title exists.', '%d skipped: stylesheets with the same titles exist.', $duplicates, 'oxygen-six-stylesheets' ),
                $duplicates
            );
        }
        if ( $invalid ) {
            $message .= ' ' . sprintf(
                /* translators: %d: number of entries */
                _n( '%d skipped: the entry is invalid.', '%d skipped: the entries are invalid.', $invalid, 'oxygen-six-stylesheets' ),
                $invalid
            );
        }

        if ( $unchecked ) {
            $message .= ' ' . sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d not saved: the CSS check failed for the stylesheet.', '%d not saved: the CSS check failed for the stylesheets.', $unchecked, 'oxygen-six-stylesheets' ),
                $unchecked
            );
        }
        if ( $failed ) {
            $message .= ' ' . sprintf(
                /* translators: %d: number of stylesheets */
                _n( '%d not saved: the database rejected the stylesheet.', '%d not saved: the database rejected the stylesheets.', $failed, 'oxygen-six-stylesheets' ),
                $failed
            );
        }

        self::set_import_result( $imported ? 'success' : 'warning', $message );
    }

    /**
     * @param string $limit A PHP size value, for example 8M.
     * @return string
     */
    private static function server_limit_message( $limit ) {
        return sprintf(
            /* translators: %s: PHP size limit, for example 8M */
            __( 'Import failed: the file is larger than the upload limit of the server (%s).', 'oxygen-six-stylesheets' ),
            $limit
        );
    }

    /**
     * Store the import notice for the next page load.
     *
     * @param string $type    Notice type: success, warning or error.
     * @param string $message
     */
    private static function set_import_result( $type, $message ) {
        set_transient( 'o6s_import_result', [ 'type' => $type, 'message' => $message ], 30 );
    }
}
