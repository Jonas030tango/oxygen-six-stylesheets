<?php
/**
 * Oxygen Six Stylesheets - Frontend CSS Injection
 *
 * Handles injecting custom stylesheets into Oxygen Builder's rendering pipeline
 * and provides a wp_head fallback for non-Oxygen contexts.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Frontend {

    /**
     * Whether the Oxygen injection path was used.
     *
     * @var bool
     */
    private static $oxygen_injected = false;

    /**
     * Sanitize CSS for safe output inside <style> tags.
     * Defense-in-depth: strips dangerous patterns even though save-time sanitization
     * should have already handled them.
     *
     * @param string $css Raw CSS string.
     * @return string Sanitized CSS safe for <style> context.
     */
    public static function sanitize_css_output( $css ) {
        // Remove any HTML tags — prevents breaking out of <style> context
        $css = preg_replace( '/<[a-z\/!]/i', '[blocked]', $css );
        return $css;
    }

    /**
     * Make a post title safe for a CSS comment inside a `<style>` element.
     *
     * sanitize_css_output() does not see the title.
     *
     * @param string $title Raw post title.
     * @return string Title safe for CSS comment context inside <style>.
     */
    private static function escape_css_comment( $title ) {
        return str_replace(
            [ '*/', '/*' ],
            [ '* /', '/ *' ],
            str_replace( [ '<', '>' ], '', (string) $title )
        );
    }

    /**
     * Add the `O6S` comment markers to the CSS of a stylesheet.
     * Only a user with `edit_o6_stylesheets` sees the title in the markers.
     *
     * @param object $sheet A row from get_active_stylesheets().
     * @param string   $css Sanitized CSS.
     * @return string
     */
    private static function wrap_css( $sheet, $css ) {
        if ( ! current_user_can( 'edit_o6_stylesheets' ) ) {
            // Oxygen 6 deletes duplicate inlineStyles entries. The post ID keeps each entry unique.
            return "/* O6S: {$sheet->ID} */\n{$css}";
        }
        $name = self::escape_css_comment( $sheet->post_title );
        return "/* O6S: {$name} */\n{$css}\n/* /O6S: {$name} */";
    }

    /**
     * Initialize frontend hooks.
     *
     * The injection path depends on which Oxygen version is active:
     * - Oxygen 6      : ScriptAndStyleHolder on template_redirect, wp_head as a safety net.
     * - Oxygen 4.x    : a single late wp_head <style> — it covers both the
     *                   frontend and the builder iframe (oxygen-iframe-template.php
     *                   calls wp_head()). Priority 1000000 lands after Oxygen's
     *                   cached universal.css (wp_head @ 999999) so user CSS wins.
     * - No Oxygen     : wp_head fallback as a standalone stylesheet manager.
     */
    public static function init() {
        if ( o6s_is_oxygen_active() ) {
            // Only frontend requests fire template_redirect. Oxygen renders the page, the builder iframe
            // and its any-URL AJAX calls later, on template_include.
            add_action( 'template_redirect', [ __CLASS__, 'inject_oxygen_styles' ] );
            // Safety net if the ScriptAndStyleHolder path is unavailable.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        } elseif ( o6s_is_oxygen_classic_active() ) {
            // Oxygen 4.x (classic).
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 1000000 );
        } else {
            // Standalone: no Oxygen present.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        }

        // WordPress before 6.3 does not change the "posts" last_changed value on a meta write.
        if ( ! has_action( 'updated_post_meta', 'wp_cache_set_posts_last_changed' ) ) {
            foreach ( [ 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ] as $hook ) {
                add_action( $hook, [ __CLASS__, 'meta_changed' ], 10, 3 );
            }
        }
    }

    /**
     * Change the "posts" last_changed value after a write to a meta key that get_active_stylesheets() reads.
     *
     * @param int|int[] $meta_id
     * @param int       $post_id
     * @param string    $meta_key
     */
    public static function meta_changed( $meta_id, $post_id, $meta_key ) {
        if ( $meta_key === '_o6s_css' || $meta_key === '_o6s_priority' ) {
            wp_cache_set_posts_last_changed();
        }
    }

    /**
     * Primary injection path: Append CSS to Oxygen's ScriptAndStyleHolder.
     */
    public static function inject_oxygen_styles() {
        // Only proceed if Oxygen's ScriptAndStyleHolder is available
        if ( ! class_exists( '\Breakdance\Render\ScriptAndStyleHolder' ) ) {
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        $inline_styles = [];
        foreach ( $stylesheets as $sheet ) {
            if ( ! empty( trim( $sheet->css ) ) ) {
                $inline_styles[] = self::wrap_css( $sheet, self::sanitize_css_output( $sheet->css ) );
            }
        }

        if ( ! empty( $inline_styles ) ) {
            \Breakdance\Render\ScriptAndStyleHolder::getInstance()->append( [
                'inlineStyles' => $inline_styles,
            ] );
            self::$oxygen_injected = true;
        }
    }

    /**
     * Fallback injection via wp_head.
     *
     * Used for the Oxygen 4.x frontend + builder iframe and for non-Oxygen
     * (standalone) contexts. On Oxygen 6 it only fires if the primary
     * ScriptAndStyleHolder path was not used.
     */
    public static function inject_fallback_styles() {
        if ( self::$oxygen_injected ) {
            return;
        }

        // Oxygen 4.x: skip the builder UI shell so user CSS does not bleed into
        // the builder chrome. The shell defines SHOW_CT_BUILDER but not
        // OXYGEN_IFRAME; the iframe preview defines both; the frontend neither.
        if ( defined( 'SHOW_CT_BUILDER' ) && ! defined( 'OXYGEN_IFRAME' ) ) {
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        foreach ( $stylesheets as $sheet ) {
            if ( ! empty( trim( $sheet->css ) ) ) {
                // The id uses the post ID: a title slug shows the title to visitors.
                echo "<style id=\"o6s-" . (int) $sheet->ID . "\">\n";
                echo self::wrap_css( $sheet, self::sanitize_css_output( $sheet->css ) ) . "\n";
                echo "</style>\n";
            }
        }
    }

    /**
     * Load the published stylesheets ordered by priority.
     *
     * The object cache keeps the result with the "posts" last_changed value.
     * The ORDER BY is the same as in PostType::order_by_priority().
     *
     * @return object[] Each item has the fields ID, post_title and css.
     */
    public static function get_active_stylesheets() {
        static $cache = null;
        if ( $cache !== null ) {
            return $cache;
        }

        $last_changed = wp_cache_get_last_changed( 'posts' );
        $entry        = wp_cache_get( 'active_stylesheets', 'o6s' );
        if ( is_array( $entry ) && $entry['last_changed'] === $last_changed ) {
            $cache = $entry['rows'];
            return $cache;
        }

        global $wpdb;
        // The subquery reads the first CSS row, as get_post_meta() does.
        $cache = $wpdb->get_results(
            "SELECT p.ID, p.post_title,
                ( SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_o6s_css' ORDER BY meta_id ASC LIMIT 1 ) AS css
            FROM {$wpdb->posts} AS p
            LEFT JOIN {$wpdb->postmeta} AS prio ON ( prio.post_id = p.ID AND prio.meta_key = '_o6s_priority' )
            WHERE p.post_type = 'o6_stylesheet' AND p.post_status = 'publish'
            ORDER BY COALESCE( CAST( NULLIF( prio.meta_value, '' ) AS SIGNED ), 10 ) ASC, p.ID ASC"
        );
        foreach ( $cache as $sheet ) {
            // get_post_meta() also unserializes.
            $sheet->css = (string) maybe_unserialize( $sheet->css );
        }

        // An empty result after a database error must not stay in the cache.
        if ( $wpdb->last_error === '' ) {
            wp_cache_set( 'active_stylesheets', [ 'last_changed' => $last_changed, 'rows' => $cache ], 'o6s' );
        }
        return $cache;
    }
}
