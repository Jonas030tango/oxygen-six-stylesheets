<?php
/**
 * Oxygen Six Stylesheets - Cached CSS file for visitors
 *
 * Builds the CSS file of the published sheets and keeps its manifest.
 * The design is in Developement/plan-12-css-files.md, section 2.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Files {

    /** Functions that take a URL as a string argument. */
    const URL_FUNCTIONS = [ 'url', 'src', 'image', 'image-set', '-webkit-image-set', 'cross-fade' ];

    /** Without "//" after the colon, a URL of these schemes depends on the scheme of the base. */
    const SPECIAL_SCHEMES = [ 'http', 'https', 'ftp', 'ws', 'wss', 'file' ];

    const WHITESPACE = " \t\n\r\f";

    /**
     * Marks of this request: site ID => 'changed' or 'schedule'.
     *
     * @var string[]
     */
    private static $marks = [];

    /**
     * True when the plugin list held the plugin at plugins_loaded.
     *
     * @var bool
     */
    private static $listed = false;

    public static function init() {
        $base         = plugin_basename( O6S_PLUGIN_FILE );
        self::$listed = in_array( $base, (array) get_option( 'active_plugins', [] ), true )
            || ( is_multisite() && isset( ( (array) get_site_option( 'active_sitewide_plugins', [] ) )[ $base ] ) );

        add_action( 'added_post_meta', [ __CLASS__, 'meta_written' ], 10, 3 );
        add_action( 'updated_post_meta', [ __CLASS__, 'meta_written' ], 10, 3 );
        add_action( 'deleted_post_meta', [ __CLASS__, 'meta_deleted' ], 10, 3 );
        add_action( 'transition_post_status', [ __CLASS__, 'status_changed' ], 10, 3 );
        add_action( 'post_updated', [ __CLASS__, 'type_changed' ], 10, 3 );
        add_action( 'add_option_o6s_settings', [ __CLASS__, 'changed' ], 10, 0 );
        add_action( 'update_option_o6s_settings', [ __CLASS__, 'changed' ], 10, 0 );
        add_action( 'o6s_daily_check', [ __CLASS__, 'daily_check' ] );
        add_action( 'shutdown', [ __CLASS__, 'build_dirty' ], 1000 );
    }

    public static function install() {
        self::write_stamp();
        add_option( 'o6s_settings', [ 'files' => true ], '', true );
        if ( ! wp_next_scheduled( 'o6s_daily_check' ) ) {
            wp_schedule_event( time(), 'daily', 'o6s_daily_check' );
        }
    }

    /**
     * @return array{files: bool}
     */
    public static function settings() {
        $settings = get_option( 'o6s_settings' );
        return [ 'files' => ! is_array( $settings ) || ! empty( $settings['files'] ) ];
    }

    public static function enabled() {
        return self::settings()['files'] && apply_filters( 'o6s_files_enabled', true );
    }

    /**
     * @param int    $meta_id
     * @param int    $post_id
     * @param string $meta_key
     */
    public static function meta_written( $meta_id, $post_id, $meta_key ) {
        if ( self::is_sheet_key( $meta_key ) ) {
            $post = get_post( $post_id );
            if ( $post && $post->post_type === 'o6_stylesheet' && $post->post_status === 'publish' ) {
                self::changed();
            }
        }
    }

    /**
     * @param int[]  $meta_ids
     * @param int    $post_id
     * @param string $meta_key
     */
    public static function meta_deleted( $meta_ids, $post_id, $meta_key ) {
        // delete_metadata() with $delete_all passes one ID but deletes the rows of all posts.
        if ( self::is_sheet_key( $meta_key ) ) {
            self::changed();
        }
    }

    /**
     * @param string   $new_status
     * @param string   $old_status
     * @param \WP_Post $post
     */
    public static function status_changed( $new_status, $old_status, $post ) {
        if ( $post->post_type === 'o6_stylesheet' && $new_status !== $old_status
            && ( $new_status === 'publish' || $old_status === 'publish' ) ) {
            self::changed();
        }
    }

    /**
     * @param int      $post_id
     * @param \WP_Post $after
     * @param \WP_Post $before
     */
    public static function type_changed( $post_id, $after, $before ) {
        if ( $after->post_type !== $before->post_type
            && ( $after->post_type === 'o6_stylesheet' || $before->post_type === 'o6_stylesheet' )
            && ( $after->post_status === 'publish' || $before->post_status === 'publish' ) ) {
            self::changed();
        }
    }

    private static function is_sheet_key( $meta_key ) {
        return $meta_key === '_o6s_css' || $meta_key === '_o6s_priority';
    }

    /**
     * A write can change the file. Visitors get the inline output from now on.
     */
    public static function changed() {
        // uninstall.php deletes the sheets after the options.
        if ( defined( 'WP_UNINSTALL_PLUGIN' ) ) {
            return;
        }
        self::write_stamp();
        self::$marks[ get_current_blog_id() ] = 'changed';
    }

    /**
     * Ask for a build at the end of the request. The stamp stays.
     */
    public static function schedule() {
        $blog = get_current_blog_id();
        if ( ! isset( self::$marks[ $blog ] ) ) {
            self::$marks[ $blog ] = 'schedule';
        }
    }

    public static function pending() {
        return self::$marks;
    }

    public static function build_dirty() {
        $marks       = self::$marks;
        self::$marks = [];
        if ( ! $marks || defined( 'WP_UNINSTALL_PLUGIN' ) ) {
            return;
        }
        $current = get_current_blog_id();
        // This stamp comes after the last write of the request, so no build can save a part of the writes.
        foreach ( $marks as $blog => $mark ) {
            if ( $mark !== 'changed' ) {
                continue;
            }
            $switch = $blog !== $current;
            if ( $switch ) {
                switch_to_blog( $blog );
            }
            // A request that started before the uninstall must not write a stamp after it.
            if ( self::plugin_active() ) {
                self::write_stamp();
            }
            if ( $switch ) {
                restore_current_blog();
            }
        }
        // Another site builds on its next visitor request, in its own context and uploads directory.
        if ( ! isset( $marks[ $current ] ) ) {
            return;
        }
        if ( ! self::enabled() ) {
            if ( $marks[ $current ] === 'changed' ) {
                do_action( 'o6s_output_changed' );
            }
            return;
        }
        if ( function_exists( 'fastcgi_finish_request' ) ) {
            fastcgi_finish_request();
        } elseif ( function_exists( 'litespeed_finish_request' ) ) {
            litespeed_finish_request();
        }
        $marks[ $current ] === 'changed' ? self::build_stamped() : self::build();
    }

    /**
     * @return string '' or the error.
     */
    public static function rebuild() {
        if ( ! self::plugin_active() ) {
            return __( 'The plugin is not active.', 'oxygen-six-stylesheets' );
        }
        self::write_stamp();
        return self::build_stamped();
    }

    /**
     * @return string '' or the error.
     */
    private static function build_stamped() {
        $fired    = did_action( 'o6s_output_changed' );
        $error    = self::build();
        $manifest = self::read_manifest();
        $stopped  = ( $manifest['rev'] ?? null ) !== self::read_stamp( false ) || self::served( $manifest ) === null;
        if ( $stopped && did_action( 'o6s_output_changed' ) === $fired ) {
            do_action( 'o6s_output_changed' );
        }
        return $error;
    }

    /**
     * Build the file for the current stamp. Plan section 2.6.
     *
     * @return string '' or the error.
     */
    public static function build() {
        $lock = self::lock();
        if ( $lock === '' ) {
            return __( 'Another build runs. Try again in one minute.', 'oxygen-six-stylesheets' );
        }
        $changed = false;
        try {
            if ( ! self::plugin_active() ) {
                return __( 'The plugin is not active.', 'oxygen-six-stylesheets' );
            }
            $error = self::build_locked( $changed );
        } finally {
            self::unlock( $lock );
        }
        // After the unlock: a listener can take time.
        if ( $changed ) {
            do_action( 'o6s_output_changed' );
        }
        return $error;
    }

    /**
     * Plan 2.6 steps 1 to 6.
     *
     * @return string '' or the error.
     */
    private static function build_locked( &$changed ) {
        $rev = self::read_stamp();
        $old = self::read_manifest();
        if ( $old && ! self::check( $old, $rev ) ) {
            return '';
        }

        // The modification time of a file marks the end of its use. The cleanup counts from it.
        // A file that touch() cannot change keeps its old time, so the manifest pins it for the retention period.
        $dir     = self::dir();
        $touched = true;
        $pinned  = array_filter( (array) ( $old['pinned'] ?? [] ), function ( $time ) {
            return $time > self::retention_limit();
        } );
        foreach ( $old['variants'] ?? [] as $variant ) {
            $path = $dir . '/' . ( $variant['file'] ?? '' );
            if ( ( $variant['file'] ?? '' ) !== '' && is_file( $path ) && ! @touch( $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
                $touched                     = false;
                $pinned[ $variant['file'] ] = time();
            }
        }
        // A web build that stops without a save still starts the one-hour rule of manifest().
        $unfinished           = self::record( $rev, __( 'The build did not finish.', 'oxygen-six-stylesheets' ) );
        $unfinished['pinned'] = $pinned;
        update_option( 'o6s_files', $unfinished, self::autoload() );

        $manifest = self::make( $rev, $dir );
        if ( $manifest === null ) {
            return __( 'The plugin is not active.', 'oxygen-six-stylesheets' );
        }

        if ( self::read_stamp( false ) !== $rev ) {
            self::flush_option_cache();
            return __( 'A stylesheet changed during the build. The next build starts after that change.', 'oxygen-six-stylesheets' );
        }
        if ( ! self::plugin_active() ) {
            return __( 'The plugin is not active.', 'oxygen-six-stylesheets' );
        }
        $manifest['pinned'] = $pinned;
        update_option( 'o6s_files', $manifest, self::autoload() );
        if ( $touched ) {
            self::cleanup( $dir, array_merge( array_column( $manifest['variants'], 'file' ), array_keys( $pinned ) ) );
        }
        $served  = self::served( $manifest );
        $changed = $served === null || $served !== self::served( $old );
        return $manifest['error'];
    }

    /**
     * @param array|false $manifest
     * @return string[]|null NULL: the output is not known.
     */
    private static function served( $manifest ) {
        if ( ( $manifest['error'] ?? '' ) !== '' ) {
            return ( $manifest['inline'] ?? '' ) === '' ? null : [ '' => ( $manifest['version'] ?? '' ) . ':' . ( $manifest['context'] ?? '' ) . ':' . $manifest['inline'] ];
        }
        return array_map( function ( $variant ) {
            return $variant['file'] ?? '';
        }, (array) ( $manifest['variants'] ?? [] ) );
    }

    /**
     * Plan 2.6 steps 3 and 4.
     *
     * @param string $rev
     * @param string $dir
     * @return array|null The manifest, or NULL when the plugin is not active before the write.
     */
    private static function make( $rev, $dir ) {
        global $wpdb;
        if ( method_exists( $wpdb, 'send_reads_to_masters' ) ) {
            $wpdb->send_reads_to_masters();
        }
        $rows = Frontend::load_stylesheets();
        if ( $wpdb->last_error !== '' ) {
            return self::record( $rev, __( 'The database query of the stylesheets failed.', 'oxygen-six-stylesheets' ) );
        }
        $part = self::partition( $rows, o6s_oxygen_context() );
        if ( $part['sheets'] ) {
            return self::record( $rev, __( 'Some stylesheets cannot go into the file.', 'oxygen-six-stylesheets' ), $part['sheets'], self::inline_hash( $rows ) );
        }
        $manifest = self::record( $rev, '' );
        if ( $part['css'] === '' ) {
            $manifest['variants'] = [ '*' => [ 'file' => '', 'bytes' => 0 ] ];
            return $manifest;
        }

        $prefix = self::prefix();
        foreach ( self::variants( $part['css'], self::language_hosts() ) as $host => $css ) {
            if ( ! self::plugin_active() ) {
                return null;
            }
            $name  = $prefix . substr( md5( $css ), 0, 12 ) . '.css';
            $error = self::write( $dir, $name, $css );
            if ( $error === '' ) {
                $error = self::verify( $name, strlen( $css ) );
            }
            if ( $error !== '' ) {
                return self::record( $rev, $error, [], self::inline_hash( $rows ) );
            }
            $manifest['variants'][ $host ] = [ 'file' => $name, 'bytes' => strlen( $css ) ];
        }
        return $manifest;
    }

    /**
     * @param object[] $rows
     * @return string
     */
    private static function inline_hash( $rows ) {
        // Visitors do not see the titles (#13).
        return md5( serialize( array_map( function ( $row ) {
            return [ $row->ID, $row->css ];
        }, $rows ) ) );
    }

    /**
     * Build the variants in memory and compare their names with the manifest. Plan 2.7.
     */
    public static function daily_check() {
        if ( ! self::enabled() ) {
            return;
        }
        global $wpdb;
        $manifest = get_option( 'o6s_files' );
        $rows     = Frontend::load_stylesheets();
        if ( ! is_array( $manifest ) || $wpdb->last_error !== '' || self::check( $manifest, get_option( 'o6s_rev' ) ) ) {
            self::rebuild();
            return;
        }
        $part = self::partition( $rows, o6s_oxygen_context() );
        $want = [ '*' => '' ];
        if ( $part['css'] !== '' ) {
            $want = [];
            foreach ( self::variants( $part['css'], self::language_hosts() ) as $host => $css ) {
                $want[ $host ] = self::prefix() . substr( md5( $css ), 0, 12 ) . '.css';
            }
        }
        if ( $part['sheets'] || array_column( $manifest['variants'], 'file' ) !== array_values( $want )
            || array_keys( $manifest['variants'] ) !== array_keys( $want ) ) {
            self::rebuild();
        }
    }

    /**
     * The manifest for a visitor request, or NULL. Plan 2.4.
     *
     * @return array|null
     */
    public static function manifest() {
        $manifest = get_option( 'o6s_files' );
        if ( ! is_array( $manifest ) ) {
            self::schedule();
            return null;
        }
        $rev   = get_option( 'o6s_rev' );
        $fails = self::check( $manifest, $rev, strtolower( $_SERVER['HTTP_HOST'] ?? '' ) );
        if ( ! $fails ) {
            return $manifest;
        }
        $time   = (int) ( $manifest['time'] ?? 0 );
        $recent = in_array( 'error', $fails, true ) && ( $manifest['rev'] ?? null ) === $rev
            && ( $manifest['origin'] ?? '' ) === 'web' && $time > time() - HOUR_IN_SECONDS;
        // During a deploy, another server can still save a manifest of the old version or site.
        $recent = $recent || ( $fails === [ 'env' ] && $time > time() - 10 * MINUTE_IN_SECONDS );
        // A build cannot change the host of the request.
        if ( ! $recent && $fails !== [ 'host' ] ) {
            self::schedule();
        }
        return null;
    }

    /**
     * The manifest when it is valid for each host, or NULL. It adds no mark.
     *
     * @return array|null
     */
    public static function valid_manifest() {
        $manifest = get_option( 'o6s_files' );
        return is_array( $manifest ) && ! self::check( $manifest, get_option( 'o6s_rev' ) ) ? $manifest : null;
    }

    /**
     * @return bool True while a build holds the lock.
     */
    public static function building() {
        global $wpdb;
        $lock = (string) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'o6s_files_lock'" );
        return $lock > sprintf( '%010d', time() - 60 );
    }

    /**
     * The failed conditions of plan 2.4.
     *
     * @param array       $manifest
     * @param mixed       $rev  The current stamp.
     * @param string|null $host The host of the request. NULL: skip the autoload test, and each variant must have its file.
     * @return string[] Empty when the manifest is valid.
     */
    private static function check( $manifest, $rev, $host = null ) {
        $fails = [];
        if ( ! is_string( $rev ) || ( $manifest['rev'] ?? null ) !== $rev ) {
            $fails[] = 'rev';
        }
        if ( ( $manifest['error'] ?? 'x' ) !== '' ) {
            $fails[] = 'error';
        }
        if ( $host !== null ) {
            $all = wp_load_alloptions();
            if ( wp_using_ext_object_cache() ? isset( $all['o6s_rev'] ) || isset( $all['o6s_files'] ) : ! isset( $all['o6s_rev'] ) ) {
                $fails[] = 'autoload';
            }
        }
        if ( ( $manifest['version'] ?? '' ) !== O6S_VERSION || ( $manifest['context'] ?? null ) !== o6s_oxygen_context()
            || ( $manifest['site'] ?? '' ) !== self::site() ) {
            $fails[] = 'env';
        }
        if ( $fails || ! is_array( $manifest['variants'] ?? null ) ) {
            return $fails ?: [ 'error' ];
        }
        $variants = $manifest['variants'];
        if ( $host !== null ) {
            $variant = $variants['*'] ?? $variants[ $host ] ?? null;
            if ( $variant === null ) {
                return [ 'host' ];
            }
            $variants = [ $variant ];
        }
        foreach ( $variants as $variant ) {
            if ( $variant['file'] !== '' && ! is_file( self::dir() . '/' . $variant['file'] ) ) {
                return [ 'file' ];
            }
        }
        return [];
    }

    /**
     * The link for the variant of the request, or ''.
     *
     * @param array $manifest A result of manifest().
     * @return string
     */
    public static function link_html( $manifest ) {
        $variants = $manifest['variants'];
        $variant  = $variants['*'] ?? $variants[ strtolower( $_SERVER['HTTP_HOST'] ?? '' ) ] ?? null;
        if ( ! $variant || $variant['file'] === '' ) {
            return '';
        }
        $url = wp_get_upload_dir()['baseurl'] . '/o6s/' . $variant['file'];
        if ( is_ssl() ) {
            $url = set_url_scheme( $url, 'https' );
        }
        return '<link rel="stylesheet" id="o6s-css" href="' . esc_url( $url ) . '">';
    }

    /**
     * Split the CSS into tokens as "CSS Syntax Module Level 3", section 4, specifies.
     *
     * @param string $css
     * @return array{clean: bool, import: bool, url: string, roots: array[]}
     *     clean:  the CSS ends clean and cannot change the CSS after it (plan 2.5 step 1).
     *     import: an at-keyword "import" or "namespace".
     *     url:    the first relative URL, 'var()' for a var() in a URL function, or ''.
     *     roots:  the root URLs: start, length, value, and kind ('url' token or 'string').
     */
    public static function scan( $css ) {
        $s      = (string) $css;
        $n      = strlen( $s );
        $i      = 0;
        $stack  = [];
        $out    = [ 'clean' => true, 'import' => false, 'url' => '', 'roots' => [] ];
        $last   = '';
        $import = false;
        while ( $i < $n ) {
            $c     = $s[ $i ];
            $start = $i;
            if ( $c === '/' && ( $s[ $i + 1 ] ?? '' ) === '*' ) {
                $end = strpos( $s, '*/', $i + 2 );
                if ( $end === false ) {
                    $out['clean'] = false;
                    break;
                }
                $i = $end + 2;
                continue;
            }
            if ( strpos( self::WHITESPACE, $c ) !== false ) {
                $i += strspn( $s, self::WHITESPACE, $i );
                continue;
            }
            $after_import = $import;
            $import       = false;
            $last         = $c;
            if ( $c === '"' || $c === "'" ) {
                list( $value, $state ) = self::string_token( $s, $i );
                if ( $state !== 'ok' ) {
                    $out['clean'] = false;
                } elseif ( $after_import || self::in_url_function( $stack ) ) {
                    self::add_url( $out, $value, $start, $i - $start, 'string' );
                }
            } elseif ( $c === '(' || $c === '[' || $c === '{' ) {
                $stack[] = $c;
                $i++;
            } elseif ( $c === ')' || $c === ']' || $c === '}' ) {
                $top  = (string) end( $stack );
                $open = [ ')' => '(', ']' => '[', '}' => '{' ][ $c ];
                if ( $top === $open || ( $c === ')' && strncmp( $top, 'f:', 2 ) === 0 ) ) {
                    array_pop( $stack );
                } else {
                    $out['clean'] = false;
                }
                $i++;
            } elseif ( $c === '@' ) {
                $i++;
                if ( self::starts_ident( $s, $i ) ) {
                    $name = strtolower( self::ident( $s, $i ) );
                    if ( $name === 'import' || $name === 'namespace' ) {
                        $out['import'] = true;
                        $import        = $name === 'import';
                    }
                }
            } elseif ( $c === '#' ) {
                $i++;
                if ( $i < $n && ( self::is_ident_char( $s[ $i ] ) || self::valid_escape( $s, $i ) ) ) {
                    self::ident( $s, $i );
                }
            } elseif ( self::starts_number( $s, $i ) ) {
                self::number( $s, $i );
            } elseif ( $c === '-' && substr( $s, $i, 3 ) === '-->' ) {
                $i += 3;
            } elseif ( $c === '<' && substr( $s, $i, 4 ) === '<!--' ) {
                $i += 4;
            } elseif ( self::starts_ident( $s, $i ) ) {
                self::ident_like( $s, $i, $stack, $out );
            } else {
                $i++;
            }
        }
        // A sheet of only comments and whitespace also ends clean.
        if ( $stack || ( $last !== '}' && $last !== '' ) ) {
            $out['clean'] = false;
        }
        return $out;
    }

    /**
     * Consume an ident-like token: an ident, a function token or a url token.
     */
    private static function ident_like( $s, &$i, &$stack, &$out ) {
        $start = $i;
        $name  = strtolower( self::ident( $s, $i ) );
        if ( ( $s[ $i ] ?? '' ) !== '(' ) {
            return;
        }
        $i++;
        if ( $name === 'url' ) {
            $j    = $i + strspn( $s, self::WHITESPACE, $i );
            $next = $s[ $j ] ?? '';
            if ( $next !== '"' && $next !== "'" ) {
                $i                     = $j;
                list( $value, $state ) = self::url_token( $s, $i );
                if ( $state !== 'ok' ) {
                    $out['clean'] = false;
                } else {
                    self::add_url( $out, $value, $start, $i - $start, 'url' );
                }
                return;
            }
        }
        if ( $name === 'var' && self::in_url_function( $stack ) ) {
            // The value of the variable is unknown here.
            self::add_url( $out, 'var()', $start, 0, 'var' );
        }
        $stack[] = 'f:' . $name;
    }

    private static function in_url_function( $stack ) {
        $top = (string) end( $stack );
        return strncmp( $top, 'f:', 2 ) === 0 && in_array( substr( $top, 2 ), self::URL_FUNCTIONS, true );
    }

    /**
     * Classify one URL and add it to the scan result.
     *
     * @param array  $out
     * @param string $value  The decoded value.
     * @param int    $start  The byte offset of the token.
     * @param int    $length The byte length of the token.
     * @param string $kind   'url', 'string' or 'var'.
     */
    private static function add_url( &$out, $value, $start, $length, $kind ) {
        if ( $kind === 'var' ) {
            $out['url'] = $out['url'] === '' ? $value : $out['url'];
            return;
        }
        // CSS Values 4: a URL that starts with "#" points into the page, inline and in the file.
        if ( ( $value[0] ?? '' ) === '#' ) {
            return;
        }
        // The URL parser deletes the outer spaces and control characters and deletes tabs and line breaks.
        // It reads "\" as "/" in an http or https URL, but not in the query or the fragment.
        // The input preprocessing makes "\0" U+FFFD, so the trim must not delete it.
        $url = str_replace( [ "\t", "\n", "\r" ], '', trim( str_replace( "\0", "\u{FFFD}", $value ), "\x00..\x20" ) );
        $end = strcspn( $url, '?#' );
        $url = str_replace( '\\', '/', substr( $url, 0, $end ) ) . substr( $url, $end );
        if ( strncmp( $url, '//', 2 ) === 0 ) {
            return;
        }
        // A value that is empty or starts with "#" only after the trim resolves against the base: it is relative.
        if ( $url !== '' && preg_match( '/^([a-z][a-z0-9+.\-]*):/i', $url, $m ) ) {
            if ( ! in_array( strtolower( $m[1] ), self::SPECIAL_SCHEMES, true ) || substr( $url, strlen( $m[0] ), 2 ) === '//' ) {
                return;
            }
        } elseif ( $url !== '' && $url[0] === '/' ) {
            $out['roots'][] = [ 'start' => $start, 'length' => $length, 'value' => $url, 'kind' => $kind ];
            return;
        }
        if ( $out['url'] === '' ) {
            $out['url'] = $value;
        }
    }

    /**
     * Consume a string token. $i is at the quote.
     *
     * @return array{0: string, 1: string} The decoded value, and 'ok', 'open' (end of the CSS) or 'bad' (a line break).
     */
    private static function string_token( $s, &$i ) {
        $n     = strlen( $s );
        $quote = $s[ $i++ ];
        $value = '';
        while ( true ) {
            $len    = strcspn( $s, $quote . "\\\n\r\f", $i );
            $value .= substr( $s, $i, $len );
            $i     += $len;
            if ( $i >= $n ) {
                return [ $value, 'open' ];
            }
            $c = $s[ $i ];
            if ( $c === $quote ) {
                $i++;
                return [ $value, 'ok' ];
            }
            if ( $c !== '\\' ) {
                // The line break is not part of the bad-string token.
                return [ $value, 'bad' ];
            }
            $i++;
            if ( $i >= $n ) {
                continue;
            }
            if ( substr( $s, $i, 2 ) === "\r\n" ) {
                $i += 2;
            } elseif ( strpos( "\n\r\f", $s[ $i ] ) !== false ) {
                $i++;
            } else {
                $value .= self::escape( $s, $i );
            }
        }
    }

    /**
     * Consume a url token. $i is after "url(" and its whitespace.
     *
     * @return array{0: string, 1: string} The decoded value, and 'ok', 'open' or 'bad'.
     */
    private static function url_token( $s, &$i ) {
        $n = strlen( $s );
        // "\0" is not in the list: the input preprocessing makes it U+FFFD.
        $stop  = ")\"'(\\" . self::WHITESPACE . "\x01\x02\x03\x04\x05\x06\x07\x08\x0B\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F\x7F";
        $value = '';
        while ( true ) {
            $len    = strcspn( $s, $stop, $i );
            $value .= substr( $s, $i, $len );
            $i     += $len;
            if ( $i >= $n ) {
                return [ $value, 'open' ];
            }
            $c = $s[ $i ];
            if ( $c === ')' ) {
                $i++;
                return [ $value, 'ok' ];
            }
            if ( strpos( self::WHITESPACE, $c ) !== false ) {
                $i += strspn( $s, self::WHITESPACE, $i );
                if ( $i >= $n ) {
                    return [ $value, 'open' ];
                }
                if ( $s[ $i ] === ')' ) {
                    $i++;
                    return [ $value, 'ok' ];
                }
            } elseif ( $c === '\\' && self::valid_escape( $s, $i ) ) {
                $i++;
                $value .= self::escape( $s, $i );
                continue;
            }
            // The remnants of a bad url.
            while ( $i < $n && $s[ $i ] !== ')' ) {
                if ( self::valid_escape( $s, $i ) ) {
                    $i++;
                    self::escape( $s, $i );
                } else {
                    $i++;
                }
            }
            $i = min( $i + 1, $n );
            return [ $value, 'bad' ];
        }
    }

    /**
     * Consume an ident sequence and return its decoded value.
     */
    private static function ident( $s, &$i ) {
        static $chars = null;
        if ( $chars === null ) {
            $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' . "\0" . implode( '', array_map( 'chr', range( 0x80, 0xFF ) ) );
        }
        $n     = strlen( $s );
        $value = '';
        while ( $i < $n ) {
            $len = strspn( $s, $chars, $i );
            if ( $len ) {
                $value .= substr( $s, $i, $len );
                $i     += $len;
            } elseif ( self::valid_escape( $s, $i ) ) {
                $i++;
                $value .= self::escape( $s, $i );
            } else {
                break;
            }
        }
        return $value;
    }

    /**
     * Consume a numeric token.
     */
    private static function number( $s, &$i ) {
        if ( $s[ $i ] === '+' || $s[ $i ] === '-' ) {
            $i++;
        }
        $i += strspn( $s, '0123456789', $i );
        if ( ( $s[ $i ] ?? '' ) === '.' && ctype_digit( $s[ $i + 1 ] ?? '' ) ) {
            $i += 1 + strspn( $s, '0123456789', $i + 1 );
        }
        $e = $s[ $i ] ?? '';
        if ( $e === 'e' || $e === 'E' ) {
            $d = $s[ $i + 1 ] ?? '';
            if ( ctype_digit( $d ) ) {
                $i += 1 + strspn( $s, '0123456789', $i + 1 );
            } elseif ( ( $d === '+' || $d === '-' ) && ctype_digit( $s[ $i + 2 ] ?? '' ) ) {
                $i += 2 + strspn( $s, '0123456789', $i + 2 );
            }
        }
        if ( self::starts_ident( $s, $i ) ) {
            self::ident( $s, $i );
        } elseif ( ( $s[ $i ] ?? '' ) === '%' ) {
            $i++;
        }
    }

    /**
     * Consume an escape. $i is after the backslash.
     *
     * @return string The code point as UTF-8.
     */
    private static function escape( $s, &$i ) {
        $n = strlen( $s );
        if ( $i >= $n ) {
            return "\u{FFFD}";
        }
        $len = strspn( $s, '0123456789abcdefABCDEF', $i, 6 );
        if ( ! $len ) {
            return $s[ $i++ ];
        }
        $cp = hexdec( substr( $s, $i, $len ) );
        $i += $len;
        if ( substr( $s, $i, 2 ) === "\r\n" ) {
            $i += 2;
        } elseif ( $i < $n && strpos( self::WHITESPACE, $s[ $i ] ) !== false ) {
            $i++;
        }
        if ( $cp === 0 || ( $cp >= 0xD800 && $cp <= 0xDFFF ) || $cp > 0x10FFFF ) {
            $cp = 0xFFFD;
        }
        if ( $cp < 0x80 ) {
            return chr( $cp );
        }
        if ( $cp < 0x800 ) {
            return chr( 0xC0 | $cp >> 6 ) . chr( 0x80 | $cp & 0x3F );
        }
        if ( $cp < 0x10000 ) {
            return chr( 0xE0 | $cp >> 12 ) . chr( 0x80 | $cp >> 6 & 0x3F ) . chr( 0x80 | $cp & 0x3F );
        }
        return chr( 0xF0 | $cp >> 18 ) . chr( 0x80 | $cp >> 12 & 0x3F ) . chr( 0x80 | $cp >> 6 & 0x3F ) . chr( 0x80 | $cp & 0x3F );
    }

    private static function valid_escape( $s, $i ) {
        return ( $s[ $i ] ?? '' ) === '\\' && ! in_array( $s[ $i + 1 ] ?? '', [ "\n", "\r", "\f" ], true );
    }

    private static function is_ident_start( $c ) {
        return $c !== '' && ( ctype_alpha( $c ) || $c === '_' || $c === "\0" || ord( $c ) >= 0x80 );
    }

    private static function is_ident_char( $c ) {
        return self::is_ident_start( $c ) || ctype_digit( $c ) || $c === '-';
    }

    private static function starts_ident( $s, $i ) {
        $c = $s[ $i ] ?? '';
        if ( $c === '-' ) {
            $d = $s[ $i + 1 ] ?? '';
            return $d === '-' || self::is_ident_start( $d ) || self::valid_escape( $s, $i + 1 );
        }
        return $c === '\\' ? self::valid_escape( $s, $i ) : self::is_ident_start( $c );
    }

    private static function starts_number( $s, $i ) {
        $c = $s[ $i ] ?? '';
        $d = $s[ $i + 1 ] ?? '';
        if ( $c === '+' || $c === '-' ) {
            return ctype_digit( $d ) || ( $d === '.' && ctype_digit( $s[ $i + 2 ] ?? '' ) );
        }
        return $c === '.' ? ctype_digit( $d ) : ctype_digit( $c );
    }

    /**
     * Make the content of the file from the rows. Plan 2.5 step 2.
     *
     * @param object[] $rows    Rows of Frontend::load_stylesheets(), in priority order.
     * @param string   $context A value of o6s_oxygen_context().
     * @return array{css: string, sheets: string[]} The content, or '' and the refused sheets (ID => reason).
     */
    public static function partition( $rows, $context ) {
        $blocks = [];
        $sheets = [];
        $seen   = [];
        foreach ( $rows as $row ) {
            if ( empty( trim( $row->css ) ) ) {
                continue;
            }
            // Oxygen 6 prints a sheet with two _o6s_priority rows once.
            if ( $context === 'oxygen6' ) {
                if ( isset( $seen[ $row->ID ] ) ) {
                    continue;
                }
                $seen[ $row->ID ] = true;
            }
            $css  = Frontend::sanitize_css_output( $row->css );
            $scan = self::scan( $css );
            if ( ! $scan['clean'] ) {
                $sheets[ (int) $row->ID ] = __( 'ends with open CSS', 'oxygen-six-stylesheets' );
            } elseif ( $scan['import'] ) {
                $sheets[ (int) $row->ID ] = __( 'uses @import or @namespace', 'oxygen-six-stylesheets' );
            } elseif ( $scan['url'] !== '' ) {
                $sheets[ (int) $row->ID ] = __( 'relative URL', 'oxygen-six-stylesheets' );
            } else {
                $blocks[] = Frontend::visitor_block( $row->ID, $css );
            }
        }
        if ( $sheets ) {
            return [ 'css' => '', 'sheets' => $sheets ];
        }
        // The format of the inline output: Oxygen 6 joins its entries, inject_fallback_styles() ends each one.
        $css = $context === 'oxygen6' ? implode( "\n", $blocks ) : ( $blocks ? implode( "\n", $blocks ) . "\n" : '' );
        return [ 'css' => $css, 'sheets' => [] ];
    }

    /**
     * The language homes as URLs. The first one is home.
     *
     * @return string[]
     */
    public static function language_hosts() {
        $homes = [];
        $wpml  = apply_filters( 'wpml_active_languages', null, [ 'skip_missing' => 0 ] );
        if ( is_array( $wpml ) ) {
            foreach ( array_keys( $wpml ) as $code ) {
                $homes[] = apply_filters( 'wpml_permalink', home_url( '/' ), $code, true );
            }
        }
        if ( function_exists( 'pll_languages_list' ) ) {
            // The property home_url is deprecated in Polylang 3.4 and later.
            foreach ( (array) pll_languages_list( [ 'fields' => '' ] ) as $lang ) {
                $homes[] = method_exists( $lang, 'get_home_url' ) ? $lang->get_home_url() : $lang->home_url;
            }
        }
        $homes = array_merge( [ get_option( 'home' ) ], (array) apply_filters( 'o6s_language_hosts', $homes ) );
        $out   = [];
        foreach ( $homes as $home ) {
            $host = self::host( $home );
            if ( $host !== '' && ! isset( $out[ $host ] ) ) {
                $out[ $host ] = (string) $home;
            }
        }
        return array_values( $out );
    }

    /**
     * The variants of the content: '*' without a root URL, else one per language host. Plan 2.5 step 4.
     *
     * @param string   $css
     * @param string[] $homes The language homes.
     * @return string[] host => content.
     */
    public static function variants( $css, $homes ) {
        $roots = self::scan( $css )['roots'];
        if ( ! $roots ) {
            return [ '*' => $css ];
        }
        $out = [];
        foreach ( $homes as $home ) {
            $host = self::host( $home );
            if ( $host === '' || isset( $out[ $host ] ) ) {
                continue;
            }
            $v   = '';
            $pos = 0;
            foreach ( $roots as $root ) {
                // Without a scheme, the URL takes the scheme of the file, as the inline output takes the scheme of the page.
                $string = '"' . strtr( '//' . $host . $root['value'], [ '"' => '\\"', '\\' => '\\\\', "\n" => '\\a ', "\r" => '\\d ', "\f" => '\\c ' ] ) . '"';
                $v     .= substr( $css, $pos, $root['start'] - $pos ) . ( $root['kind'] === 'url' ? "url({$string})" : $string );
                $pos    = $root['start'] + $root['length'];
            }
            $out[ $host ] = $v . substr( $css, $pos );
        }
        return $out;
    }

    /**
     * @param string $url
     * @return string The host (plan 2.1, Terms). '' without a host.
     */
    private static function host( $url ) {
        $parts = parse_url( (string) $url ); // phpcs:ignore WordPress.WP.AlternativeFunctions
        if ( empty( $parts['host'] ) ) {
            return '';
        }
        $host = $parts['host'];
        // Browsers send the punycode form of a Unicode host.
        if ( function_exists( 'idn_to_ascii' ) ) {
            $host = idn_to_ascii( $host, IDNA_NONTRANSITIONAL_TO_ASCII, INTL_IDNA_VARIANT_UTS46 ) ?: $host;
        }
        // Browsers leave out the default port.
        $default = [ 'http' => 80, 'https' => 443 ][ strtolower( $parts['scheme'] ?? '' ) ] ?? null;
        $port    = isset( $parts['port'] ) && $parts['port'] !== $default ? ':' . $parts['port'] : '';
        return strtolower( $host ) . $port;
    }

    /**
     * Write one file. Plan 2.6 step 4.
     *
     * @return string '' or the error.
     */
    private static function write( $dir, $name, $css ) {
        if ( wp_is_stream( $dir ) ) {
            return __( 'The uploads directory is a stream.', 'oxygen-six-stylesheets' );
        }
        /* translators: %s: file path */
        $failed = __( 'Cannot write %s.', 'oxygen-six-stylesheets' );
        if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
            return sprintf( $failed, $dir );
        }
        // phpcs:disable WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
        if ( ! is_file( $dir . '/index.php' ) && @file_put_contents( $dir . '/index.php', '' ) === false ) {
            return sprintf( $failed, $dir . '/index.php' );
        }
        $path = $dir . '/' . $name;
        clearstatcache( true, $path );
        if ( is_file( $path ) && filesize( $path ) === strlen( $css ) ) {
            return '';
        }
        $tmp = $path . '.' . uniqid() . '.tmp';
        if ( @file_put_contents( $tmp, $css ) !== strlen( $css ) ) {
            @unlink( $tmp );
            return sprintf( $failed, $tmp );
        }
        if ( ! @rename( $tmp, $path ) ) {
            @unlink( $tmp );
            // Another build can write the same file at the same time.
            clearstatcache( true, $path );
            if ( ! is_file( $path ) || filesize( $path ) !== strlen( $css ) ) {
                return sprintf( $failed, $path );
            }
        }
        // The permissions of wp_upload_bits().
        $stat = @stat( $dir );
        @chmod( $path, $stat ? $stat['mode'] & 0000666 : 0644 );
        // phpcs:enable
        return '';
    }

    /**
     * Request the file over HTTP. Plan 2.6 step 4.
     *
     * @return string '' or the error.
     */
    private static function verify( $name, $bytes ) {
        $home = get_option( 'home' );
        $base = wp_get_upload_dir()['baseurl'];
        // A language plugin can give baseurl the host of the request. wp_safe_remote_get() accepts the home host as written.
        if ( in_array( self::host( $base ), array_map( [ self::class, 'host' ], self::language_hosts() ), true ) ) {
            $h    = wp_parse_url( $home );
            $base = $h['scheme'] . '://' . $h['host'] . ( isset( $h['port'] ) ? ':' . $h['port'] : '' ) . wp_parse_url( $base, PHP_URL_PATH );
        }
        $url      = set_url_scheme( $base . '/o6s/' . $name, wp_parse_url( $home, PHP_URL_SCHEME ) );
        $response = wp_safe_remote_get( $url, [
            'timeout'   => 3,
            'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
        ] );
        if ( is_wp_error( $response ) ) {
            $status = $response->get_error_message();
            $type   = '';
        } else {
            $status = (string) wp_remote_retrieve_response_code( $response );
            $type   = wp_remote_retrieve_header( $response, 'content-type' );
            $type   = is_array( $type ) ? (string) end( $type ) : (string) $type;
            $ok     = $status === '200' && preg_match( '#^text/css\s*(;|$)#i', $type )
                && strlen( wp_remote_retrieve_body( $response ) ) === $bytes;
            if ( $ok && preg_match( '/;\s*charset\s*=\s*"?([^";\s]+)/i', $type, $m ) ) {
                $charsets = [ strtolower( $m[1] ), strtolower( get_option( 'blog_charset' ) ) ];
                $charsets = str_replace( 'utf8', 'utf-8', $charsets );
                $ok       = $charsets[0] === $charsets[1];
            }
            if ( $ok ) {
                return '';
            }
        }
        /* translators: 1: HTTP status, 2: content type, 3: file URL */
        return sprintf( __( 'The file URL returns %1$s %2$s: %3$s', 'oxygen-six-stylesheets' ), $status, $type, $url );
    }

    /**
     * Delete the old files of this site. Plan 2.6 step 6.
     *
     * @param string   $dir
     * @param string[] $keep The files of the new manifest and the pinned files.
     */
    private static function cleanup( $dir, $keep ) {
        $prefix = self::prefix();
        $others = [];
        foreach ( glob( $dir . '/' . $prefix . str_repeat( '[0-9a-f]', 12 ) . '.css' ) ?: [] as $path ) {
            if ( ! in_array( basename( $path ), $keep, true ) ) {
                $others[ $path ] = (int) @filemtime( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            }
        }
        arsort( $others );
        foreach ( array_slice( $others, 3, null, true ) as $path => $mtime ) {
            if ( $mtime < self::retention_limit() ) {
                @unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            }
        }
        foreach ( glob( $dir . '/' . $prefix . '*.tmp' ) ?: [] as $path ) {
            if ( (int) @filemtime( $path ) < time() - HOUR_IN_SECONDS ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
                @unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            }
        }
    }

    /**
     * @return int The cleanup can delete a replaced file older than this time.
     */
    private static function retention_limit() {
        return time() - (int) ( DAY_IN_SECONDS * (float) apply_filters( 'o6s_file_retention_days', 7 ) );
    }

    /**
     * A manifest without variants.
     *
     * @param string   $rev
     * @param string   $error
     * @param string[] $sheets ID => reason.
     * @param string   $inline The hash of the rows, or '' when it is not known.
     * @return array
     */
    private static function record( $rev, $error, $sheets = [], $inline = '' ) {
        return [
            'rev'      => $rev,
            'version'  => O6S_VERSION,
            'context'  => o6s_oxygen_context(),
            'site'     => self::site(),
            'variants' => [],
            'error'    => $error,
            'origin'   => ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron() ? 'cli' : 'web',
            'sheets'   => $sheets,
            'inline'   => $inline,
            'time'     => time(),
        ];
    }

    /**
     * Read the stamp from the database. Plan 2.6 step 1.
     *
     * @param bool $repair Add a missing stamp, set the autoload values and clear stale caches.
     * @return string|null
     */
    private static function read_stamp( $repair = true ) {
        global $wpdb;
        $sql = "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'o6s_rev'";
        $rev = $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( ! $repair ) {
            return $rev;
        }
        $flush = false;
        if ( $rev === null ) {
            $wpdb->query( $wpdb->prepare(
                "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES ('o6s_rev', %s, %s)",
                uniqid( '', true ),
                self::autoload_value()
            ) );
            $rev   = $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $flush = true;
        }
        $autoload = function_exists( 'wp_autoload_values_to_autoload' ) ? wp_autoload_values_to_autoload() : [ 'yes' ];
        $rows     = $wpdb->get_results( "SELECT option_name, autoload FROM {$wpdb->options} WHERE option_name IN ('o6s_rev', 'o6s_files')" );
        foreach ( $rows as $row ) {
            if ( in_array( $row->autoload, $autoload, true ) !== self::autoload() ) {
                $wpdb->update( $wpdb->options, [ 'autoload' => self::autoload_value() ], [ 'option_name' => $row->option_name ] );
                $flush = true;
            }
        }
        if ( $flush || $rev !== get_option( 'o6s_rev' ) || self::read_manifest() !== get_option( 'o6s_files' ) ) {
            self::flush_option_cache();
        }
        return $rev;
    }

    /**
     * @return array|false The manifest in the database.
     */
    private static function read_manifest() {
        global $wpdb;
        $value = $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'o6s_files'" );
        return $value === null ? false : maybe_unserialize( $value );
    }

    private static function flush_option_cache() {
        foreach ( [ 'alloptions', 'notoptions', 'o6s_rev', 'o6s_files' ] as $key ) {
            wp_cache_delete( $key, 'options' );
        }
    }

    private static function write_stamp() {
        update_option( 'o6s_rev', uniqid( '', true ), self::autoload() );
    }

    /**
     * With an external object cache, each option has its own cache key.
     * An old copy of alloptions then cannot bring back an old stamp and manifest.
     */
    private static function autoload() {
        return ! wp_using_ext_object_cache();
    }

    private static function autoload_value() {
        $new = function_exists( 'wp_autoload_values_to_autoload' );
        return self::autoload() ? ( $new ? 'on' : 'yes' ) : ( $new ? 'off' : 'no' );
    }

    /**
     * @return string The value of the lock row, or '' when another build holds it.
     */
    public static function lock() {
        global $wpdb;
        $value = sprintf( '%010d %s', time(), uniqid( '', true ) );
        if ( $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES ('o6s_files_lock', %s, 'no')", $value ) ) === 1 ) {
            return $value;
        }
        $stale = sprintf( '%010d', time() - 60 );
        if ( $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = 'o6s_files_lock' AND option_value < %s", $value, $stale ) ) === 1 ) {
            return $value;
        }
        return '';
    }

    private static function unlock( $value ) {
        global $wpdb;
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = 'o6s_files_lock' AND option_value = %s", $value ) );
    }

    public static function plugin_active() {
        // A mu-plugin or a require runs without the list.
        if ( ! self::$listed ) {
            return true;
        }
        global $wpdb;
        $base = plugin_basename( O6S_PLUGIN_FILE );
        $list = maybe_unserialize( $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'active_plugins'" ) );
        if ( is_array( $list ) && in_array( $base, $list, true ) ) {
            return true;
        }
        if ( ! is_multisite() ) {
            return false;
        }
        $network = maybe_unserialize( $wpdb->get_var( $wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key = 'active_sitewide_plugins' AND site_id = %d",
            get_current_network_id()
        ) ) );
        return is_array( $network ) && isset( $network[ $base ] );
    }

    private static function site() {
        // Only the path: a language plugin can change the host of baseurl on each request.
        return md5( get_option( 'home' ) . '|' . wp_parse_url( wp_get_upload_dir()['baseurl'], PHP_URL_PATH ) );
    }

    /**
     * The cleanup deletes only names with this prefix, so two sites that share uploads/o6s/ keep their files.
     */
    public static function prefix() {
        return 'o6s-' . substr( self::site(), 0, 8 );
    }

    private static function dir() {
        return wp_get_upload_dir()['basedir'] . '/o6s';
    }
}
