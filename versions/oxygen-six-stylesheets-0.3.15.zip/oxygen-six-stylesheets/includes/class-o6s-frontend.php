<?php
/**
 * Oxygen Six Stylesheets - Frontend CSS Injection
 *
 * Handles injecting custom stylesheets into Oxygen Builder's rendering pipeline
 * and provides a wp_head fallback for non-Oxygen contexts.
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Frontend {

    /**
     * Whether the Oxygen injection path was used.
     *
     * @var bool
     */
    private static $oxygen_injected = false;

    /**
     * The link of the file for the filter oxygen_variables_css.
     *
     * @var string
     */
    private static $link = '';

    /**
     * The rows of get_active_stylesheets() for this request.
     *
     * @var object[]|null
     */
    private static $rows = null;

    /**
     * Sanitize CSS for safe output inside <style> tags.
     * Defense-in-depth: strips dangerous patterns even though save-time sanitization
     * should have already handled them.
     *
     * @param string $css Raw CSS string.
     * @return string Sanitized CSS safe for <style> context.
     */
    public static function sanitize_css_output( $css ) {
        // Remove any HTML tags — prevents breaking out of <style> context
        $css = preg_replace( '/<[a-z\/!]/i', '[blocked]', $css );
        return $css;
    }

    /**
     * Make a post title safe for a CSS comment inside a `<style>` element.
     *
     * sanitize_css_output() does not see the title.
     *
     * @param string $title Raw post title.
     * @return string Title safe for CSS comment context inside <style>.
     */
    private static function escape_css_comment( $title ) {
        return str_replace(
            [ '*/', '/*' ],
            [ '* /', '/ *' ],
            str_replace( [ '<', '>' ], '', (string) $title )
        );
    }

    /**
     * Add the `O6S` comment markers to the CSS of a stylesheet.
     * Only a user with `edit_o6_stylesheets` sees the title in the markers.
     *
     * @param object $sheet A row from get_active_stylesheets().
     * @param string   $css Sanitized CSS.
     * @return string
     */
    private static function wrap_css( $sheet, $css ) {
        if ( ! current_user_can( 'edit_o6_stylesheets' ) ) {
            return self::visitor_block( $sheet->ID, $css );
        }
        $name = self::escape_css_comment( $sheet->post_title );
        return "/* O6S: {$name} */\n{$css}\n/* /O6S: {$name} */";
    }

    /**
     * The block of a sheet for a visitor, inline and in the file.
     *
     * @param int    $id  Post ID.
     * @param string $css Sanitized CSS.
     * @return string
     */
    public static function visitor_block( $id, $css ) {
        // Oxygen 6 deletes duplicate inlineStyles entries. The post ID keeps each entry unique.
        return "/* O6S: {$id} */\n{$css}";
    }

    /**
     * Initialize frontend hooks.
     *
     * The injection path depends on which Oxygen version is active:
     * - Oxygen 6      : ScriptAndStyleHolder on template_redirect, wp_head as a safety net.
     * - Oxygen 4.x    : a single late wp_head <style> — it covers both the
     *                   frontend and the builder iframe (oxygen-iframe-template.php
     *                   calls wp_head()). Priority 1000000 lands after Oxygen's
     *                   cached universal.css (wp_head @ 999999) so user CSS wins.
     * - No Oxygen     : wp_head fallback as a standalone stylesheet manager.
     */
    public static function init() {
        if ( o6s_is_oxygen_active() ) {
            // Only frontend requests fire template_redirect. Oxygen renders the page, the builder iframe
            // and its any-URL AJAX calls later, on template_include.
            add_action( 'template_redirect', [ __CLASS__, 'inject_oxygen_styles' ] );
            // Safety net if the ScriptAndStyleHolder path is unavailable.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        } elseif ( o6s_is_oxygen_classic_active() ) {
            // Oxygen 4.x (classic).
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 1000000 );
        } else {
            // Standalone: no Oxygen present.
            add_action( 'wp_head', [ __CLASS__, 'inject_fallback_styles' ], 999 );
        }

        add_action( 'post_updated', [ __CLASS__, 'title_changed' ], 10, 3 );
    }

    /**
     * The logged-in output shows the title in its markers, but the file does not. So a title change writes no stamp.
     *
     * @param int      $post_id
     * @param \WP_Post $after
     * @param \WP_Post $before
     */
    public static function title_changed( $post_id, $after, $before ) {
        if ( $after->post_type === 'o6_stylesheet' && $after->post_status === 'publish' && $after->post_title !== $before->post_title ) {
            wp_cache_set( 'last_changed', microtime(), 'o6s' );
        }
    }

    /**
     * The key of the cache entry of get_active_stylesheets().
     *
     * @return string
     */
    public static function cache_key() {
        return (string) get_option( 'o6s_rev' ) . ' ' . wp_cache_get_last_changed( 'o6s' );
    }

    /**
     * Oxygen 6: the link of the file for a visitor, else the sheets as inlineStyles entries.
     */
    public static function inject_oxygen_styles() {
        // Only proceed if Oxygen's ScriptAndStyleHolder is available
        if ( ! class_exists( '\Breakdance\Render\ScriptAndStyleHolder' ) ) {
            return;
        }
        // An Oxygen app template, for example the builder shell, never prints the holder.
        if ( function_exists( '\Breakdance\ActionsFilters\getAdminTemplate' ) && \Breakdance\ActionsFilters\getAdminTemplate() ) {
            return;
        }

        $manifest = self::visitor_manifest();
        if ( $manifest ) {
            $link       = Files::link_html( $manifest );
            self::$link = $link === '' ? '' : $link . "\n";
            // The end of the "variables" part is directly before the inlineStyles part.
            add_filter( 'oxygen_variables_css', [ __CLASS__, 'append_link' ], PHP_INT_MAX );
            self::$oxygen_injected = true;
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        $inline_styles = [];
        foreach ( $stylesheets as $sheet ) {
            if ( ! empty( trim( $sheet->css ) ) ) {
                $inline_styles[] = self::wrap_css( $sheet, self::sanitize_css_output( $sheet->css ) );
            }
        }

        if ( ! empty( $inline_styles ) ) {
            \Breakdance\Render\ScriptAndStyleHolder::getInstance()->append( [
                'inlineStyles' => $inline_styles,
            ] );
            self::$oxygen_injected = true;
        }
    }

    /**
     * Fallback injection via wp_head.
     *
     * Used for the Oxygen 4.x frontend + builder iframe and for non-Oxygen
     * (standalone) contexts. On Oxygen 6 it only fires if the primary
     * ScriptAndStyleHolder path was not used.
     */
    public static function inject_fallback_styles() {
        if ( self::$oxygen_injected ) {
            return;
        }

        // Oxygen 4.x: skip the builder UI shell so user CSS does not bleed into
        // the builder chrome. The shell defines SHOW_CT_BUILDER but not
        // OXYGEN_IFRAME; the iframe preview defines both; the frontend neither.
        if ( defined( 'SHOW_CT_BUILDER' ) && ! defined( 'OXYGEN_IFRAME' ) ) {
            return;
        }

        $manifest = self::visitor_manifest();
        if ( $manifest ) {
            $link = Files::link_html( $manifest );
            if ( $link !== '' ) {
                echo $link . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- link_html() escapes the URL.
            }
            return;
        }

        $stylesheets = self::get_active_stylesheets();
        if ( empty( $stylesheets ) ) {
            return;
        }

        foreach ( $stylesheets as $sheet ) {
            if ( ! empty( trim( $sheet->css ) ) ) {
                // The id uses the post ID: a title slug shows the title to visitors.
                echo "<style id=\"o6s-" . (int) $sheet->ID . "\">\n";
                echo self::wrap_css( $sheet, self::sanitize_css_output( $sheet->css ) ) . "\n";
                echo "</style>\n";
            }
        }
    }

    /**
     * @param string $css The HTML of the Oxygen "variables" part.
     * @return string
     */
    public static function append_link( $css ) {
        return $css . self::$link;
    }

    /**
     * The manifest of the file for a visitor, or NULL for the inline output.
     *
     * @return array|null
     */
    private static function visitor_manifest() {
        if ( ! Files::enabled() || current_user_can( 'edit_o6_stylesheets' )
            || ( function_exists( '\Breakdance\isRequestFromBuilderIframe' ) && \Breakdance\isRequestFromBuilderIframe() )
            || ( function_exists( '\Breakdance\BrowseMode\isRequestFromBrowserIframe' ) && \Breakdance\BrowseMode\isRequestFromBrowserIframe() )
            || defined( 'OXYGEN_IFRAME' ) || self::holder_has_styles()
            // Without the holder, inject_fallback_styles() prints each row, but the oxygen6 file holds a sheet only once.
            || ( o6s_oxygen_context() === 'oxygen6' && ! class_exists( '\\Breakdance\\Render\\ScriptAndStyleHolder' ) ) ) {
            return null;
        }
        return Files::manifest();
    }

    /**
     * True when the Oxygen 6 holder has an inlineStyles entry. The sheets must come after it.
     *
     * @return bool
     */
    public static function holder_has_styles() {
        return o6s_oxygen_context() === 'oxygen6' && class_exists( '\Breakdance\Render\ScriptAndStyleHolder' )
            && ! empty( \Breakdance\Render\ScriptAndStyleHolder::getInstance()->dependencies['inlineStyles'] );
    }

    /**
     * Load the published stylesheets ordered by priority.
     *
     * The object cache keeps the result with cache_key(). A write that fires no hook shows after one day at the latest.
     *
     * @return object[] Each item has the fields ID, post_title and css.
     */
    public static function get_active_stylesheets() {
        if ( self::$rows !== null ) {
            return self::$rows;
        }

        $key   = self::cache_key();
        $entry = wp_cache_get( 'active_stylesheets', 'o6s' );
        if ( is_array( $entry ) && ( $entry['key'] ?? null ) === $key ) {
            self::$rows = $entry['rows'];
            return self::$rows;
        }

        global $wpdb;
        // A replica can lag behind the write that changed the key. Its rows would then stay under the new key.
        // Only the sheet query goes to the primary database.
        $primary = wp_using_ext_object_cache() && method_exists( $wpdb, 'send_reads_to_masters' ) && property_exists( $wpdb, 'srtm' );
        if ( $primary ) {
            $srtm = $wpdb->srtm;
            $wpdb->send_reads_to_masters();
        }
        self::$rows = self::load_stylesheets();
        if ( $primary ) {
            $wpdb->srtm = $srtm;
        }

        // An empty result after a database error must not stay in the cache.
        if ( $wpdb->last_error === '' ) {
            wp_cache_set( 'active_stylesheets', [ 'key' => $key, 'rows' => self::$rows ], 'o6s', DAY_IN_SECONDS );
        }
        return self::$rows;
    }

    /**
     * Query the published sheets without a cache.
     * The order is the same as in PostType::order_by_priority().
     *
     * @return object[]
     */
    public static function load_stylesheets() {
        global $wpdb;
        // The subquery reads the first CSS row, as get_post_meta() does.
        // PHP sorts the rows: an ORDER BY copies all CSS into a temporary table and sorts it there (#11).
        $rows = $wpdb->get_results(
            "SELECT p.ID, p.post_title,
                COALESCE( CAST( NULLIF( prio.meta_value, '' ) AS SIGNED ), 10 ) AS priority,
                ( SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = p.ID AND meta_key = '_o6s_css' ORDER BY meta_id ASC LIMIT 1 ) AS css
            FROM {$wpdb->posts} AS p
            LEFT JOIN {$wpdb->postmeta} AS prio ON ( prio.post_id = p.ID AND prio.meta_key = '_o6s_priority' )
            WHERE p.post_type = 'o6_stylesheet' AND p.post_status = 'publish'"
        );
        usort( $rows, function ( $a, $b ) {
            return (int) $a->priority <=> (int) $b->priority ?: (int) $a->ID <=> (int) $b->ID;
        } );
        foreach ( $rows as $sheet ) {
            unset( $sheet->priority );
            // get_post_meta() also unserializes.
            $sheet->css = (string) maybe_unserialize( $sheet->css );
        }
        return $rows;
    }
}
