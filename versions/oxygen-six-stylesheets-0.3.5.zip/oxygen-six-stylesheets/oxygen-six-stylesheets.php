<?php
/**
 * Plugin Name: Oxygen Six Stylesheets
 * Plugin URI: https://github.com/Jonas030tango/oxygen-six-stylesheets
 * Description: Add custom, named stylesheets to Oxygen Builder (4.x classic and 6) — editable from the WordPress backend, organized with categories, and loaded live in the builder.
 * Version: 0.3.5
 * Author: Jonas Karanlik Zadow
 * Author URI: https://github.com/Jonas030tango
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: oxygen-six-stylesheets
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'O6S_VERSION', '0.3.5' );
define( 'O6S_PLUGIN_FILE', __FILE__ );
define( 'O6S_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'O6S_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check if Oxygen Builder 6 is active.
 */
function o6s_is_oxygen_active() {
    return defined( 'BREAKDANCE_MODE' ) && BREAKDANCE_MODE === 'oxygen';
}

/**
 * Check if Oxygen Builder 4.x (classic) is active.
 *
 * The classic builder defines CT_VERSION but not BREAKDANCE_MODE. Oxygen 6 is
 * checked first so a v6 install is never misclassified as classic.
 */
function o6s_is_oxygen_classic_active() {
    return defined( 'CT_VERSION' ) && ! o6s_is_oxygen_active();
}

/**
 * Resolve which Oxygen builder is active.
 *
 * @return string 'oxygen6' | 'classic' | '' (no Oxygen).
 */
function o6s_oxygen_context() {
    if ( o6s_is_oxygen_active() ) {
        return 'oxygen6';
    }
    if ( o6s_is_oxygen_classic_active() ) {
        return 'classic';
    }
    return '';
}

/**
 * Show admin notice if no supported Oxygen Builder version is active.
 */
function o6s_admin_notice_no_oxygen() {
    if ( o6s_oxygen_context() !== '' ) {
        return;
    }
    ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php esc_html_e( 'Oxygen Six Stylesheets', 'oxygen-six-stylesheets' ); ?>:</strong>
            <?php esc_html_e( 'Oxygen Builder is not active. The plugin will still work as a standalone stylesheet manager, but styles will not appear in the Oxygen builder.', 'oxygen-six-stylesheets' ); ?>
        </p>
    </div>
    <?php
}
add_action( 'admin_notices', 'o6s_admin_notice_no_oxygen' );

/**
 * Load plugin files.
 */
function o6s_init() {
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-post-type.php';
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-admin.php';
    require_once O6S_PLUGIN_DIR . 'includes/class-o6s-frontend.php';

    OxygenSixStylesheets\PostType::register();
    OxygenSixStylesheets\Admin::init();
    OxygenSixStylesheets\Frontend::init();
}
add_action( 'plugins_loaded', 'o6s_init' );
