<?php
/**
 * Oxygen Six Stylesheets - Custom Post Type & Taxonomy
 */

namespace OxygenSixStylesheets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class PostType {

    /**
     * Register CPT and taxonomy hooks.
     */
    public static function register() {
        add_action( 'init', [ __CLASS__, 'register_post_type' ] );
        add_action( 'init', [ __CLASS__, 'register_taxonomy' ] );
        add_action( 'init', [ __CLASS__, 'maybe_create_default_term' ], 20 );
        add_action( 'admin_init', [ __CLASS__, 'maybe_map_capabilities' ] );
    }

    /**
     * Only map capabilities when the plugin version changes or on first install.
     * Prevents writing to the DB on every admin page load.
     */
    public static function maybe_map_capabilities() {
        $stored_version = get_option( 'o6s_caps_version', '' );
        if ( $stored_version === O6S_VERSION ) {
            return;
        }
        self::map_capabilities();
        self::migrate_active_meta_to_status();
        update_option( 'o6s_caps_version', O6S_VERSION, true );
    }

    /**
     * One-time migration: move published stylesheets with _o6s_active='0'
     * to draft status, then clean up the meta key.
     */
    private static function migrate_active_meta_to_status() {
        $inactive = get_posts( [
            'post_type'      => 'o6_stylesheet',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'meta_key'       => '_o6s_active',
            'meta_value'     => '0',
            'fields'         => 'ids',
        ] );

        foreach ( $inactive as $post_id ) {
            wp_update_post( [ 'ID' => $post_id, 'post_status' => 'draft' ] );
        }

        // Clean up legacy meta from all stylesheets
        global $wpdb;
        $wpdb->delete( $wpdb->postmeta, [ 'meta_key' => '_o6s_active' ] );
    }

    /**
     * Map custom CPT capabilities to administrator role only.
     */
    public static function map_capabilities() {
        $role = get_role( 'administrator' );
        if ( ! $role ) {
            return;
        }

        $caps = self::get_caps();

        foreach ( $caps as $cap ) {
            if ( ! $role->has_cap( $cap ) ) {
                $role->add_cap( $cap );
            }
        }
    }

    /**
     * Remove custom CPT capabilities from all roles.
     * Used during uninstall.
     */
    public static function remove_capabilities() {
        $role = get_role( 'administrator' );
        if ( ! $role ) {
            return;
        }

        foreach ( self::get_caps() as $cap ) {
            $role->remove_cap( $cap );
        }

        delete_option( 'o6s_caps_version' );
    }

    /**
     * Get the list of custom capabilities for this CPT.
     *
     * @return string[]
     */
    public static function get_caps() {
        return [
            'edit_o6_stylesheet',
            'read_o6_stylesheet',
            'delete_o6_stylesheet',
            'edit_o6_stylesheets',
            'edit_others_o6_stylesheets',
            'publish_o6_stylesheets',
            'read_private_o6_stylesheets',
            'delete_o6_stylesheets',
            'delete_private_o6_stylesheets',
            'delete_published_o6_stylesheets',
            'delete_others_o6_stylesheets',
            'edit_private_o6_stylesheets',
            'edit_published_o6_stylesheets',
        ];
    }

    /**
     * Register the o6_stylesheet custom post type.
     */
    public static function register_post_type() {
        $labels = [
            'name'                  => __( 'Stylesheets', 'oxygen-six-stylesheets' ),
            'singular_name'         => __( 'Stylesheet', 'oxygen-six-stylesheets' ),
            'add_new'               => __( 'Add New Stylesheet', 'oxygen-six-stylesheets' ),
            'add_new_item'          => __( 'Add New Stylesheet', 'oxygen-six-stylesheets' ),
            'edit_item'             => __( 'Edit Stylesheet', 'oxygen-six-stylesheets' ),
            'new_item'              => __( 'New Stylesheet', 'oxygen-six-stylesheets' ),
            'view_item'             => __( 'View Stylesheet', 'oxygen-six-stylesheets' ),
            'search_items'          => __( 'Search Stylesheets', 'oxygen-six-stylesheets' ),
            'not_found'             => __( 'No stylesheets found.', 'oxygen-six-stylesheets' ),
            'not_found_in_trash'    => __( 'No stylesheets found in trash.', 'oxygen-six-stylesheets' ),
            'all_items'             => __( 'All Stylesheets', 'oxygen-six-stylesheets' ),
            'menu_name'             => __( 'O6 Stylesheets', 'oxygen-six-stylesheets' ),
        ];

        $args = [
            'labels'              => $labels,
            'public'              => false,
            'publicly_queryable'  => false,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'menu_position'       => 61,
            'menu_icon'           => 'dashicons-admin-appearance',
            'supports'            => [ 'title', 'revisions' ],
            'has_archive'         => false,
            'rewrite'             => false,
            'capability_type'     => 'o6_stylesheet',
            'map_meta_cap'        => true,
            'show_in_rest'        => false,
        ];

        register_post_type( 'o6_stylesheet', $args );
    }

    /**
     * Register the o6_stylesheet_cat taxonomy.
     */
    public static function register_taxonomy() {
        $labels = [
            'name'              => __( 'Stylesheet Categories', 'oxygen-six-stylesheets' ),
            'singular_name'     => __( 'Category', 'oxygen-six-stylesheets' ),
            'search_items'      => __( 'Search Categories', 'oxygen-six-stylesheets' ),
            'all_items'         => __( 'All Categories', 'oxygen-six-stylesheets' ),
            'parent_item'       => __( 'Parent Category', 'oxygen-six-stylesheets' ),
            'parent_item_colon' => __( 'Parent Category:', 'oxygen-six-stylesheets' ),
            'edit_item'         => __( 'Edit Category', 'oxygen-six-stylesheets' ),
            'update_item'       => __( 'Update Category', 'oxygen-six-stylesheets' ),
            'add_new_item'      => __( 'Add New Category', 'oxygen-six-stylesheets' ),
            'new_item_name'     => __( 'New Category Name', 'oxygen-six-stylesheets' ),
            'menu_name'         => __( 'Categories', 'oxygen-six-stylesheets' ),
        ];

        $args = [
            'labels'            => $labels,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'show_in_rest'      => false,
            'rewrite'           => false,
            'capabilities'      => [
                'manage_terms' => 'manage_options',
                'edit_terms'   => 'manage_options',
                'delete_terms' => 'manage_options',
                'assign_terms' => 'edit_o6_stylesheets',
            ],
        ];

        register_taxonomy( 'o6_stylesheet_cat', 'o6_stylesheet', $args );
    }

    /**
     * Create the default "Uncategorized" term if it doesn't exist yet.
     * Runs at priority 20 so the taxonomy is already registered.
     */
    public static function maybe_create_default_term() {
        if ( get_option( 'o6s_default_term_created' ) ) {
            return;
        }

        $existing = term_exists( 'Uncategorized', 'o6_stylesheet_cat' );
        if ( ! $existing ) {
            wp_insert_term(
                __( 'Uncategorized', 'oxygen-six-stylesheets' ),
                'o6_stylesheet_cat',
                [ 'slug' => 'uncategorized' ]
            );
        }

        update_option( 'o6s_default_term_created', '1', true );
    }
}
